<template>
    <Header></Header>
  <main class="bloge main">
    <div class="item">
      <!-- ======= section2 ======= -->
      <section class="section2__section2">
        <h1 class="section2__hero_title">Блог</h1>
      </section>
      <!-- ======= End section2 ======= -->
    </div>
    <div class="item">
      <!-- ======= section3 ======= -->
      <section class="section3__section3">
        <div class="section3__col">
          <div class="section3__row">
            <div class="item">
              <div class="section3__wrapper1">
                <div class="section3__flex_row">
                  <h3 class="section3__subtitle2">Рубрики</h3>
                  <div class="item">
                    <hr class="section3__line1" size="1" />
                  </div>
                </div>
                <h4 class="">
                  <div class="section3__highlights2">
                    <a href="#" class="section3__highlights2_span0"
                      >Название рубрики </a
                    ><span class="section3__highlights2_span1">(12)</span>
                  </div>
                </h4>
                <h4 class="">
                  <div class="section3__highlights21">
                    <a href="#" class="section3__highlights21_span0"
                      >Название рубрики </a
                    ><span class="section3__highlights21_span1">(8)</span>
                  </div>
                </h4>
                <h4 class="">
                  <div class="section3__highlights21">
                    <a href="#" class="section3__highlights21_span0"
                      >Название рубрики </a
                    ><span class="section3__highlights21_span1">(3)</span>
                  </div>
                </h4>
                <h4 class="">
                  <div class="section3__highlights21">
                    <a href="#" class="section3__highlights21_span0"
                      >Название рубрики </a
                    ><span class="section3__highlights21_span1">(16)</span>
                  </div>
                </h4>
                <h4 class="">
                  <div class="section3__highlights21">
                    <a href="#" class="section3__highlights21_span0"
                      >Название рубрики </a
                    ><span class="section3__highlights21_span1">(4)</span>
                  </div>
                </h4>
                <h4 class="">
                  <div class="section3__highlights21">
                    <a href="#" class="section3__highlights21_span0"
                      >Название рубрики </a
                    ><span class="section3__highlights21_span1">(7)</span>
                  </div>
                </h4>
                <div class="section3__flex_row1">
                  <h3 class="section3__subtitle21">Главное</h3>
                  <div class="item">
                    <hr class="section3__line2" size="1" />
                  </div>
                </div>
                <img
                  class="section3__wrapper2"
                  src="../assets/img/assets/5a7764e83da7cf960ce3c6a3187da382.png"
                />
                <h3 class="section3__subtitle3">
                  <a href="#">Название статьи</a>
                </h3>
                <div class="section3__info2">
                  Краткое описание статьи или новости
                </div>
                <div class="section3__info3">20.06.2022</div>
                <img
                  class="section3__wrapper21"
                  src="../assets/img/assets/2d2d45f44799554fcf7113c8cb38f2a7.png"
                />
                <h3 class="section3__subtitle3">
                  <a href="#">Название статьи</a>
                </h3>
                <div class="section3__info2">
                  Краткое описание статьи или новости
                </div>
                <div class="section3__info3">20.06.2022</div>

                <img
                  class="section3__wrapper21"
                  src="../assets/img/assets/e67661888e06e3562a8ab9845f8fffce.png"
                />
                <h3 class="section3__subtitle3">
                  <a href="#">Название статьи</a>
                </h3>
                <div class="section3__info2">
                  Краткое описание статьи или новости
                </div>
                <div class="section3__info31">20.06.2022</div>
              </div>
            </div>
            <div class="spacer"></div>
            <div class="item1">
              <div class="section3__col1">
                <div class="section3__col2">
                  <img
                    class="section3__wrapper3"
                    src="../assets/img/assets/d9ec163ff52dacd8096c7bb1369a4278.png"
                  />

                  <h2 class="section3__medium_title">
                    <a href="#"> Центральная студия документальных фильмов </a>
                  </h2>
                  <hr class="section3__line3" size="1" />
                  <div class="section3__row1">
                    <div class="section3__info4">
                      <a href="#">Киностудии</a>
                    </div>
                    <div class="spacer"></div>
                    <div class="section3__info41">
                      <a href="#">Коллекция</a>
                    </div>
                    <div class="spacer"></div>
                    <div class="section3__info42"><a href="#">Архив</a></div>
                    <div class="spacer"></div>
                    <div class="section3__info43">
                      <a href="#">Советская кинохроника</a>
                    </div>
                    <div class="spacer"></div>
                    <div class="section3__info44">
                      <a href="#">Студии СССР</a>
                    </div>
                    <div class="spacer"></div>
                    <div class="section3__info45">
                      <a href="#">Оцифровка кинопленки</a>
                    </div>
                  </div>
                  <h5 class="section3__highlights3">
                    «Центрнаучфильм» — советская и российская киностудия
                    научно-популярных и учебных <br />фильмов. В 70-х годах
                    созданная в Москве студия выпускала более 300 фильмов в год,
                    куда <br />входили и периодические киножурналы.
                  </h5>
                  <a href="#" class="section3__wrapper4">
                    <h5 class="section3__highlights4">Читать полностью</h5>
                  </a>
                </div>
                <div class="section3__col3">
                  <img
                    class="section3__wrapper31"
                    src="../assets/img/assets/b2e0e41ffb28e48051fe4077c1f62635.png"
                  />
                  <h2 class="section3__medium_title">
                    <a href="#"> Центральная студия документальных фильмов </a>
                  </h2>
                  <hr class="section3__line31" size="1" />
                  <div class="section3__row2">
                    <div class="section3__info4">
                      <a href="#">Киностудии</a>
                    </div>
                    <div class="spacer"></div>
                    <div class="section3__info41">
                      <a href="#">Коллекция</a>
                    </div>
                    <div class="spacer"></div>
                    <div class="section3__info42"><a href="#">Архив</a></div>
                    <div class="spacer"></div>
                    <div class="section3__info43">
                      <a href="#">Советская кинохроника</a>
                    </div>
                    <div class="spacer"></div>
                    <div class="section3__info44">
                      <a href="#">Студии СССР</a>
                    </div>
                    <div class="spacer"></div>
                    <div class="section3__info45">
                      <a href="#">Оцифровка кинопленки</a>
                    </div>
                  </div>
                  <h5 class="section3__highlights31">
                    Центральная студия документальных фильмов (ЦСДФ) являлась
                    флагманом документального <br />кино. Ежегодно она выпускала
                    более 100 номеров киножурналов и около 150 документальных
                    <br />фильмов.
                  </h5>
                  <a href="#" class="section3__wrapper41">
                    <h5 class="section3__highlights4">Читать полностью</h5>
                  </a>
                </div>
                <div class="section3__col4">
                  <img
                    class="section3__wrapper3"
                    src="../assets/img/assets/b2e0e41ffb28e48051fe4077c1f62635.png"
                  />

                  <h2 class="section3__medium_title1">
                    <a href="#"> Контентный проект «Карта Истории» </a>
                  </h2>
                  <hr class="section3__line3" size="1" />
                  <div class="section3__row1">
                    <div class="section3__info4">
                      <a href="#">Киностудии</a>
                    </div>
                    <div class="spacer1"></div>
                    <div class="section3__info41">
                      <a href="#">Коллекция</a>
                    </div>
                    <div class="spacer1"></div>
                    <div class="section3__info42"><a href="#">Архив</a></div>
                    <div class="spacer1"></div>
                    <div class="section3__info43">
                      <a href="#">Советская кинохроника</a>
                    </div>
                    <div class="spacer1"></div>
                    <div class="section3__info44">
                      <a href="#">Студии СССР</a>
                    </div>
                    <div class="spacer1"></div>
                    <div class="section3__info45">
                      <a href="#">Оцифровка кинопленки</a>
                    </div>
                  </div>
                  <h5 class="section3__highlights32">
                    Цифровая карта с интегрированными в нее уникальными кино- и
                    фотоматериалами <br />крупнейших архивов России, которые
                    вовлекают аудиторию в изучение ключевых событий,
                    <br />связанных с историей страны в ХХ веке.
                  </h5>
                  <a href="#" class="section3__wrapper4">
                    <h5 class="section3__highlights4">Читать полностью</h5>
                  </a>
                </div>
                <div class="section3__col4">
                  <img
                    class="section3__wrapper3"
                    src="../assets/img/assets/c4f06a0095e2cd68508aff17693fcbe5.png"
                  />
                  <h2 class="section3__medium_title1">
                    <a href="#"> Решения для киноиндустрии на основе ИИ </a>
                  </h2>
                  <hr class="section3__line3" size="1" />
                  <div class="section3__row1">
                    <div class="section3__info4">
                      <a href="#">Киностудии</a>
                    </div>
                    <div class="spacer2"></div>
                    <div class="section3__info41">
                      <a href="#">Коллекция</a>
                    </div>
                    <div class="spacer2"></div>
                    <div class="section3__info42"><a href="#">Архив</a></div>
                    <div class="spacer2"></div>
                    <div class="section3__info43">
                      <a href="#">Советская кинохроника</a>
                    </div>
                    <div class="spacer2"></div>
                    <div class="section3__info44">
                      <a href="#">Студии СССР</a>
                    </div>
                    <div class="spacer2"></div>
                    <div class="section3__info45">
                      <a href="#">Оцифровка кинопленки</a>
                    </div>
                  </div>
                  <h5 class="section3__highlights3">
                    Видеоархив совместно с лаболаторией перспективных алгоритмов
                    НИКФИ разработал <br />несколько технологических решений,
                    которые смогут сделать работу кинокомпаний более
                    <br />эффективной.
                  </h5>
                  <a href="#" class="section3__wrapper4">
                    <h5 class="section3__highlights4">Читать полностью</h5>
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div class="section3__row3">
            <a href="#" class="item">
              <img
                class="section3__image4"
                src="../assets/img/assets/81fbcfff32ecd99ceb98d24781495915.png"
                alt="alt text"
              />
            </a>
            <div class="spacer"></div>
            <a href="#" class="item1">
              <img
                class="section3__image5"
                src="../assets/img/assets/25bfeb06b7d6a8783db87384ad645d76.png"
                alt="alt text"
              />
            </a>
            <div class="spacer"></div>
            <a href="#" class="section3__subtitle">1</a>
            <a href="#" class="section3__subtitle4">2</a>
            <a href="#" class="section3__subtitle4">3</a>
            <a href="#" class="section3__subtitle41">4</a>
            <h5 class="section3__subtitle41">...</h5>
            <a href="#" class="section3__subtitle42">16</a>
            <div class="spacer"></div>
            <a href="#" class="item1">
              <img
                class="section3__image5"
                src="../assets/img/assets/4e5ce117df73b37964344a8e896d073d.png"
                alt="alt text"
              />
            </a>
            <div class="spacer"></div>
            <a href="#" class="item">
              <img
                class="section3__image4"
                src="../assets/img/assets/8253bdda278388ee236f678e6c766cd4.png"
                alt="alt text"
              />
            </a>
          </div>
        </div>
      </section>
      <!-- ======= End section3 ======= -->
    </div>
  </main>
  <Footer></Footer>
</template>

<script>
// import "../assets/css/Bloge.css";

import Header from "@/Layouts/Header.vue";
import Footer from "@/Layouts/Footer.vue";

export default {
    name: "blog-view",
    components: {
        Header,
        Footer,
    }

};


</script>

<style scoped>
.main {
  display: flex;
  flex-direction: column;
  background-color: #242427;
  position: relative;
  overflow: hidden;
  margin-top: 100px;
}

.main > .item {
  display: flex;
  flex-direction: column;
  position: relative;
}

.section2__section2 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex-grow: 1;
}

.section2__hero_title {
  display: flex;
  justify-content: center;
  font: 700 40px/1.1 "Montserrat", Helvetica, Arial, serif;
  color: #f3f3f4;
  text-align: center;
  letter-spacing: 0px;
  width: 103px;
  position: relative;
  flex-grow: 1;
  min-width: 103px;
  margin: 20px auto 0px;
}
@media (max-width: 1199px) {
  .section2__hero_title {
    font-size: 36px;
    text-align: center;
  }
}
@media (max-width: 991px) {
  .section2__hero_title {
    font-size: 32px;
  }
}
@media (max-width: 767px) {
  .section2__hero_title {
    font-size: 28px;
  }
}
@media (max-width: 575px) {
  .section2__hero_title {
    font-size: 24px;
  }
}
@media (max-width: 383px) {
  .section2__hero_title {
    font-size: 20px;
  }
}

.section3__section3 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex-grow: 1;
}

.section3__col {
  display: flex;
  flex-direction: column;
  width: 75%;
  position: relative;
  flex-grow: 1;
  margin: 30px auto 100px;
}
@media (max-width: 1399px) {
  .section3__col {
    width: 80%;
  }
}
@media (max-width: 1199px) {
  .section3__col {
    width: 84.21%;
  }
}
@media (max-width: 991px) {
  .section3__col {
    width: 87.67%;
  }
}
@media (max-width: 767px) {
  .section3__col {
    width: 90.46%;
  }
}
@media (max-width: 575px) {
  .section3__col {
    width: 92.67%;
  }
}
@media (max-width: 479px) {
  .section3__col {
    width: 94.4%;
  }
}
@media (max-width: 383px) {
  .section3__col {
    width: 95.74%;
  }
}

.section3__row {
  display: flex;
  position: relative;
}
@media (max-width: 1399px) {
  .section3__row {
    flex-wrap: wrap;
    justify-content: flex-start;
    align-content: flex-start;
    -moz-column-gap: 0px;
    column-gap: 0px;
    row-gap: 16px;
  }
}

.section3__row > .item {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 340px;
}
@media (max-width: 1399px) {
  .section3__row > .item {
    flex: 0 0 100%;
  }
}

.section3__wrapper1 {
  display: flex;
  flex-direction: column;
  background-color: #3e3e3e;
  position: relative;
  flex-grow: 1;
  margin: 0px 0px 1365px;
}

.section3__flex_row {
  display: flex;
  position: relative;
  margin: 20px 20px 0px;
}
@media (max-width: 1199px) {
  .section3__flex_row {
    margin: 20px 16px 0px;
  }
}
@media (max-width: 991px) {
  .section3__flex_row {
    margin: 20px 12px 0px;
  }
}
@media (max-width: 575px) {
  .section3__flex_row {
    margin: 20px 8px 0px;
  }
}

.section3__subtitle2 {
  font: 700 20px/1.39 "Montserrat", Helvetica, Arial, serif;
  color: white;
  letter-spacing: 0px;
  position: relative;
  flex: 0 0 auto;
  min-width: 96px;
}
@media (max-width: 1199px) {
  .section3__subtitle2 {
    font-size: 16px;
    text-align: left;
  }
}

.section3__flex_row > .item {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 0 1 204px;
}

.section3__line1 {
  background-color: white;
  height: 1px;
  position: relative;
  margin: 21px 0px 6px 5px;
}

.section3__highlights2 {
  margin: 10px 20px 0px;
  font: 500 18px/1.39 "Montserrat", Helvetica, Arial, serif;
  color: black;
  letter-spacing: -0.3px;
  position: relative;
}
@media (max-width: 767px) {
  .section3__highlights2 {
    font-size: 12px;
    text-align: left;
  }
}
@media (max-width: 1199px) {
  .section3__highlights2 {
    margin: 10px 16px 0px;
  }
}
@media (max-width: 991px) {
  .section3__highlights2 {
    margin: 10px 12px 0px;
  }
}
@media (max-width: 575px) {
  .section3__highlights2 {
    margin: 10px 8px 0px;
  }
}

.section3__highlights2_span0 {
  font: 500 1em/1.39 "Montserrat", Helvetica, Arial, serif;
  color: white;
  font-style: normal;
  letter-spacing: 0px;
}

.section3__highlights2_span1 {
  font: 500 0.7777777778em/1.39 "Montserrat", Helvetica, Arial, serif;
  color: #a6a6a6;
  font-style: normal;
  letter-spacing: 0px;
}

.section3__highlights21 {
  margin: 5px 20px 0px;
  font: 500 18px/1.39 "Montserrat", Helvetica, Arial, serif;
  color: black;
  letter-spacing: -0.3px;
  position: relative;
}
@media (max-width: 767px) {
  .section3__highlights21 {
    font-size: 12px;
    text-align: left;
  }
}
@media (max-width: 1199px) {
  .section3__highlights21 {
    margin: 5px 16px 0px;
  }
}
@media (max-width: 991px) {
  .section3__highlights21 {
    margin: 5px 12px 0px;
  }
}
@media (max-width: 575px) {
  .section3__highlights21 {
    margin: 5px 8px 0px;
  }
}

.section3__highlights21_span0 {
  font: 500 1em/1.39 "Montserrat", Helvetica, Arial, serif;
  color: white;
  font-style: normal;
  letter-spacing: 0px;
}

.section3__highlights21_span1 {
  font: 500 0.7777777778em/1.39 "Montserrat", Helvetica, Arial, serif;
  color: #a6a6a6;
  font-style: normal;
  letter-spacing: 0px;
}

.section3__flex_row1 {
  display: flex;
  position: relative;
  margin: 20px 20px 0px;
}
@media (max-width: 1199px) {
  .section3__flex_row1 {
    margin: 20px 16px 0px;
  }
}
@media (max-width: 991px) {
  .section3__flex_row1 {
    margin: 20px 12px 0px;
  }
}
@media (max-width: 575px) {
  .section3__flex_row1 {
    margin: 20px 8px 0px;
  }
}

.section3__subtitle21 {
  font: 700 20px/1.39 "Montserrat", Helvetica, Arial, serif;
  color: white;
  letter-spacing: 0px;
  position: relative;
  flex: 0 0 auto;
  min-width: 87px;
}
@media (max-width: 1199px) {
  .section3__subtitle21 {
    font-size: 16px;
    text-align: left;
  }
}

.section3__flex_row1 > .item {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 0 1 213px;
}

.section3__line2 {
  background-color: white;
  height: 1px;
  position: relative;
  margin: 21px 0px 6px 5px;
}

.section3__wrapper2 {
  display: flex;
  flex-direction: column;
  background: var(--src) center center/cover no-repeat;
  height: 211px;
  position: relative;
  margin: 15px 20px 0px;
}
@media (max-width: 1199px) {
  .section3__wrapper2 {
    margin: 15px 16px 0px;
  }
}
@media (max-width: 991px) {
  .section3__wrapper2 {
    margin: 15px 12px 0px;
  }
}
@media (max-width: 575px) {
  .section3__wrapper2 {
    margin: 15px 8px 0px;
  }
}

.section3__subtitle3 {
  font: 600 20px/1.2 "Montserrat", Helvetica, Arial, serif;
  color: white;
  letter-spacing: 0px;
  position: relative;
  margin: 10px 20px 0px;
}
@media (max-width: 1199px) {
  .section3__subtitle3 {
    font-size: 16px;
    text-align: left;
    margin: 10px 16px 0px;
  }
}
@media (max-width: 991px) {
  .section3__subtitle3 {
    margin: 10px 12px 0px;
  }
}
@media (max-width: 575px) {
  .section3__subtitle3 {
    margin: 10px 8px 0px;
  }
}

.section3__info2 {
  font: 400 12px/1.25 "Montserrat", Helvetica, Arial, serif;
  color: white;
  letter-spacing: 0px;
  position: relative;
  margin: 3px 20px 0px;
}
@media (max-width: 1199px) {
  .section3__info2 {
    margin: 3px 16px 0px;
  }
}
@media (max-width: 991px) {
  .section3__info2 {
    margin: 3px 12px 0px;
  }
}
@media (max-width: 575px) {
  .section3__info2 {
    margin: 3px 8px 0px;
  }
}

.section3__info3 {
  font: 400 10px/1.2 "Montserrat", Helvetica, Arial, serif;
  color: #a6a6a6;
  letter-spacing: 0px;
  position: relative;
  margin: 8px 20px 0px;
}
@media (max-width: 1199px) {
  .section3__info3 {
    margin: 8px 16px 0px;
  }
}
@media (max-width: 991px) {
  .section3__info3 {
    margin: 8px 12px 0px;
  }
}
@media (max-width: 575px) {
  .section3__info3 {
    margin: 8px 8px 0px;
  }
}

.section3__wrapper21 {
  display: flex;
  flex-direction: column;
  background: var(--src) center center/cover no-repeat;
  height: 211px;
  position: relative;
  margin: 20px 20px 0px;
}
@media (max-width: 1199px) {
  .section3__wrapper21 {
    margin: 20px 16px 0px;
  }
}
@media (max-width: 991px) {
  .section3__wrapper21 {
    margin: 20px 12px 0px;
  }
}
@media (max-width: 575px) {
  .section3__wrapper21 {
    margin: 20px 8px 0px;
  }
}

.section3__info31 {
  font: 400 10px/1.2 "Montserrat", Helvetica, Arial, serif;
  color: #a6a6a6;
  letter-spacing: 0px;
  position: relative;
  margin: 8px 20px 30px;
}
@media (max-width: 1199px) {
  .section3__info31 {
    margin: 8px 16px 30px;
  }
}
@media (max-width: 991px) {
  .section3__info31 {
    margin: 8px 12px 30px;
  }
}
@media (max-width: 575px) {
  .section3__info31 {
    margin: 8px 8px 30px;
  }
}

.section3__row > .spacer {
  flex: 0 1 63px;
}
@media (max-width: 1399px) {
  .section3__row > .spacer {
    display: none;
  }
}

.section3__row > .item1 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 797px;
}
@media (max-width: 1399px) {
  .section3__row > .item1 {
    flex: 0 0 100%;
  }
}

.section3__col1 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex-grow: 1;
}

.section3__col2 {
  display: flex;
  flex-direction: column;
  position: relative;
  margin: 0px 4px 0px 0px;
}

.section3__wrapper3 {
  display: flex;
  flex-direction: column;
  background: var(--src) center center/cover no-repeat;
  height: 377px;
  position: relative;
}

.section3__medium_title {
  font: 700 25px/1.1 "Montserrat", Helvetica, Arial, serif;
  color: #f3f3f4;
  letter-spacing: -0.1px;
  position: relative;
  margin: 25px 0px 0px;
}
@media (max-width: 1199px) {
  .section3__medium_title {
    font-size: 20px;
    text-align: left;
  }
}
@media (max-width: 767px) {
  .section3__medium_title {
    font-size: 16px;
  }
}

.section3__line3 {
  background-color: white;
  height: 1px;
  position: relative;
  margin: 20px 0px 0px;
}

.section3__row1 {
  display: flex;
  width: 66.46%;
  position: relative;
  margin: 4px 0% 0px 33.54%;
}

.section3__info4 {
  font: 400 10px/1.1 "Montserrat", Helvetica, Arial, serif;
  color: #df8e75;
  letter-spacing: 0px;
  position: relative;
  flex: 0 0 auto;
  min-width: 63px;
}

.section3__row1 > .spacer {
  flex: 0 1 10px;
}

.section3__info41 {
  font: 400 10px/1.1 "Montserrat", Helvetica, Arial, serif;
  color: #df8e75;
  letter-spacing: 0px;
  position: relative;
  flex: 0 0 auto;
  min-width: 58px;
}

.section3__info42 {
  font: 400 10px/1.1 "Montserrat", Helvetica, Arial, serif;
  color: #df8e75;
  letter-spacing: 0px;
  position: relative;
  flex: 0 0 auto;
  min-width: 33px;
}

.section3__info43 {
  font: 400 10px/1.1 "Montserrat", Helvetica, Arial, serif;
  color: #df8e75;
  letter-spacing: 0px;
  position: relative;
  flex: 0 0 auto;
  min-width: 125px;
}

.section3__info44 {
  font: 400 10px/1.1 "Montserrat", Helvetica, Arial, serif;
  color: #df8e75;
  letter-spacing: 0px;
  position: relative;
  flex: 0 0 auto;
  min-width: 69px;
}

.section3__info45 {
  font: 400 10px/1.1 "Montserrat", Helvetica, Arial, serif;
  color: #df8e75;
  letter-spacing: 0px;
  position: relative;
  flex: 0 0 auto;
  min-width: 129px;
}

.section3__highlights3 {
  font: 400 16px/1.1 "Montserrat", Helvetica, Arial, serif;
  color: #f3f3f4;
  letter-spacing: 0px;
  position: relative;
  min-height: 54px;
  margin: 20px 19px 0px 0px;
}
@media (max-width: 1199px) {
  .section3__highlights3 {
    font-size: 12px;
    text-align: left;
  }
}
@media (max-width: 991px) {
  .section3__highlights3 {
    margin: 20px 12px 0px 0px;
  }
}
@media (max-width: 575px) {
  .section3__highlights3 {
    margin: 20px 8px 0px 0px;
  }
}

.section3__wrapper4 {
  display: block;
  flex-direction: column;
  background-color: #df8e75;
  width: 29.89%;
  position: relative;
  margin: 20px 70.11% 0px 0%;
}

.section3__highlights4 {
  display: flex;
  justify-content: center;
  font: 600 16px/1.25 "Montserrat", Helvetica, Arial, serif;
  color: #18181a;
  text-align: center;
  letter-spacing: 0px;
  position: relative;
  flex-grow: 1;
  margin: 10px 40px;
}
@media (max-width: 1199px) {
  .section3__highlights4 {
    font-size: 12px;
    text-align: center;
    margin: 10px 32px;
  }
}
@media (max-width: 991px) {
  .section3__highlights4 {
    margin: 10px 28px;
  }
}
@media (max-width: 767px) {
  .section3__highlights4 {
    margin: 10px 24px;
  }
}
@media (max-width: 575px) {
  .section3__highlights4 {
    margin: 10px 20px;
  }
}
@media (max-width: 479px) {
  .section3__highlights4 {
    margin: 10px 16px;
  }
}

.section3__col3 {
  display: flex;
  flex-direction: column;
  position: relative;
  margin: 60px 0px 0px;
}

.section3__wrapper31 {
  display: flex;
  flex-direction: column;
  background: var(--src) center center/cover no-repeat;
  height: 377px;
  position: relative;
  margin: 0px 4px 0px 0px;
}

.section3__line31 {
  background-color: white;
  height: 1px;
  position: relative;
  margin: 20px 4px 0px 0px;
}

.section3__row2 {
  display: flex;
  width: 66.12%;
  position: relative;
  margin: 4px 0.5% 0px 33.38%;
}

.section3__row2 > .spacer {
  flex: 0 1 10px;
}

.section3__highlights31 {
  font: 400 16px/1.1 "Montserrat", Helvetica, Arial, serif;
  color: #f3f3f4;
  letter-spacing: 0px;
  position: relative;
  min-height: 54px;
  margin: 20px 0px 0px;
}
@media (max-width: 1199px) {
  .section3__highlights31 {
    font-size: 12px;
    text-align: left;
  }
}

.section3__wrapper41 {
  display: block;
  flex-direction: column;
  background-color: #df8e75;
  width: 29.74%;
  position: relative;
  margin: 20px 70.26% 0px 0%;
}

.section3__col4 {
  display: flex;
  flex-direction: column;
  position: relative;
  margin: 60px 4px 0px 0px;
}

.section3__medium_title1 {
  font: 700 25px/1.1 "Montserrat", Helvetica, Arial, serif;
  color: #f3f3f4;
  letter-spacing: -0.2px;
  position: relative;
  margin: 25px 0px 0px;
}
@media (max-width: 1199px) {
  .section3__medium_title1 {
    font-size: 20px;
    text-align: left;
  }
}
@media (max-width: 767px) {
  .section3__medium_title1 {
    font-size: 16px;
  }
}

.section3__row1 > .spacer1 {
  flex: 0 1 10px;
}

.section3__highlights32 {
  font: 400 16px/1.1 "Montserrat", Helvetica, Arial, serif;
  color: #f3f3f4;
  letter-spacing: 0px;
  position: relative;
  min-height: 54px;
  margin: 20px 12px 0px 0px;
}
@media (max-width: 1199px) {
  .section3__highlights32 {
    font-size: 12px;
    text-align: left;
    margin: 20px 8px 0px 0px;
  }
}
@media (max-width: 575px) {
  .section3__highlights32 {
    margin: 20px 4px 0px 0px;
  }
}

.section3__row1 > .spacer2 {
  flex: 0 1 10px;
}

.section3__row3 {
  display: flex;
  width: 15.08%;
  position: relative;
  margin: 45px 34.08% 0px 50.83%;
}

.section3__row3 > .item {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 0 1 11px;
}

.section3__image4 {
  width: 11px;
  height: auto;
  vertical-align: top;
  -o-object-fit: contain;
  object-fit: contain;
  -o-object-position: center top;
  object-position: center top;
  position: relative;
  min-width: 11px;
  margin: 5px 0px;
}

.section3__row3 > .spacer {
  flex: 0 1 10px;
}

.section3__row3 > .item1 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 0 1 7px;
}

.section3__image5 {
  width: 7px;
  height: auto;
  vertical-align: top;
  -o-object-fit: contain;
  object-fit: contain;
  -o-object-position: center top;
  object-position: center top;
  position: relative;
  min-width: 7px;
  margin: 5px 0px;
}

.section3__subtitle {
  font: 500 20px/1.2 "Montserrat", Helvetica, Arial, serif;
  color: #df8e75;
  letter-spacing: 0px;
  position: relative;
  flex: 0 0 auto;
  min-width: 8px;
}
@media (max-width: 1199px) {
  .section3__subtitle {
    font-size: 16px;
    text-align: left;
  }
}

.section3__subtitle4 {
  font: 500 20px/1.2 "Montserrat", Helvetica, Arial, serif;
  color: #d9d9d9;
  letter-spacing: 0px;
  position: relative;
  flex: 0 0 auto;
  min-width: 12px;
  margin: 0px 0px 0px 5px;
}
@media (max-width: 1199px) {
  .section3__subtitle4 {
    font-size: 16px;
    text-align: left;
  }
}

.section3__subtitle41 {
  font: 500 20px/1.2 "Montserrat", Helvetica, Arial, serif;
  color: #d9d9d9;
  letter-spacing: 0px;
  position: relative;
  flex: 0 0 auto;
  min-width: 14px;
  margin: 0px 0px 0px 5px;
}
@media (max-width: 1199px) {
  .section3__subtitle41 {
    font-size: 16px;
    text-align: left;
  }
}

.section3__subtitle42 {
  font: 500 20px/1.2 "Montserrat", Helvetica, Arial, serif;
  color: #d9d9d9;
  letter-spacing: 0px;
  position: relative;
  flex: 0 0 auto;
  min-width: 20px;
  margin: 0px 0px 0px 5px;
}
@media (max-width: 1199px) {
  .section3__subtitle42 {
    font-size: 16px;
    text-align: left;
  }
}
</style>
