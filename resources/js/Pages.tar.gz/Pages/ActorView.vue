<template>
  <div class="total_wrapper">
    <div class="wrapper_actor_info">
      <div class="actor_info__img">
        <div class="actor_info__img__block">
          <img :src="(help + actor.photo)" :alt="actor.name" />
        </div>
      </div>
      <div class="actor_info__text">
        <h2>Тайка Вайтити</h2>
        <h3>О персоне</h3>
        <p>Карьера:<span>Актер, Режиссер, Сценарист, Продюсер</span></p>
        <p>Дата рождения:<span>16 августа, 1975</span></p>
        <p>Место рождения:<span>Веллингтон, Новая Зеландия</span></p>
        <p>Жанры:<span>Комедия, короткометражка, фантастика</span></p>
        <p>Всего фильмов:<span>99, 1999 — 2025</span></p>
        <h4>Лучшие фильмы</h4>
        <article>
        </article>
        <h4>Биография</h4>
        <article>
            {{actor.content}}
        </article>

      </div>
    </div>
    <div class="wrapper-allfilms">
      <div class="allfilms__block">
        <div class="allfilms__block__elem">
          <div class="allfilms__block__elem__img">
            <img src="@/assets/img/777.png" alt="" />
          </div>
          <div class="allfilms__block__elem__text">
            <p>Тор: Любовь и гром (2022)</p>
            <article>Thor: Love and Thunder, 2022</article>
          </div>
        </div>
        <div class="allfilms__block__elem">
          <div class="allfilms__block__elem__img">
            <img src="@/assets/img/777.png" alt="" />
          </div>
          <div class="allfilms__block__elem__text">
            <p>Тор: Любовь и гром (2022)</p>
            <article>Thor: Love and Thunder, 2022</article>
          </div>
        </div>
        <div class="allfilms__block__elem">
          <div class="allfilms__block__elem__img">
            <img src="@/assets/img/777.png" alt="" />
          </div>
          <div class="allfilms__block__elem__text">
            <p>Тор: Любовь и гром (2022)</p>
            <article>Thor: Love and Thunder, 2022</article>
          </div>
        </div>
      </div>
    </div>

    <div class="wrapper_foto">
      <p>Фото</p>
      <div class="carusel_line__nav">
        <div class="line__nav__left">
          <img src="@/assets/img/arrow.svg" alt="" />
        </div>
            <div class="line__nav__right">
            <img src="@/assets/img/arrow.svg" alt="" />
            </div>
      </div>
      <div class="wrapper__carusel">
        <div class="carusel__line">
          <div class="carusel_block">
            <img src="@/assets/img/actor.png" alt="" />
          </div>
          <div class="carusel_block">
            <img src="@/assets/img/actor.png" alt="" />
          </div>
          <div class="carusel_block">
            <img src="@/assets/img/actor.png" alt="" />
          </div>
          <div class="carusel_block">
            <img src="@/assets/img/actor.png" alt="" />
          </div>
          <div class="carusel_block">
            <img src="@/assets/img/actor.png" alt="" />
          </div>
          <div class="carusel_block">
            <img src="@/assets/img/actor.png" alt="" />
          </div>
          <div class="carusel_block">
            <img src="@/assets/img/actor.png" alt="" />
          </div>
          <div class="carusel_block">
            <img src="@/assets/img/actor.png" alt="" />
          </div>
          <div class="carusel_block">
            <img src="@/assets/img/actor.png" alt="" />
          </div>
          <div class="carusel_block">
            <img src="@/assets/img/actor.png" alt="" />
          </div>
          <div class="carusel_block">
            <img src="@/assets/img/actor.png" alt="" />
          </div>
          <div class="carusel_block">
            <img src="@/assets/img/actor.png" alt="" />
          </div>
          <div class="carusel_block">
            <img src="@/assets/img/actor.png" alt="" />
          </div>
          <div class="carusel_block">
            <img src="@/assets/img/actor.png" alt="" />
          </div>
          <div class="carusel_block">
            <img src="@/assets/img/actor.png" alt="" />
          </div>
          <div class="carusel_block">
            <img src="@/assets/img/actor.png" alt="" />
          </div>
          <div class="carusel_block">
            <img src="@/assets/img/actor.png" alt="" />
          </div>
          <div class="carusel_block">
            <img src="@/assets/img/actor.png" alt="" />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import help from "@/Components/helper-api";
import Header from "@/Layouts/Header.vue";
import Footer from "@/Layouts/Footer.vue";

export default {
  name: "actor-view",
  props:[
    'actor'
    ],
    components: {
        Header,
        Footer,
    },
  methods: {
    movecarusel(step, block) {
      document.querySelector(block).scrollTo({
        left: step,
        top: 0,
        behavior: "smooth",
      });
    },
  },
  mounted() {
    let positionCollection = 0;
    // let positionTems = 0;
    // let positionCategory = 0;
    // let positionNews = 0;

    let caruselStep = 200;

    let collectionLength =
      (document.querySelector(".carusel__line").children.length - 3) *
      caruselStep;

    document.querySelector(".line__nav__right").onclick = () => {
      positionCollection += caruselStep;
      if (positionCollection > collectionLength) {
        positionCollection = collectionLength;
      }
      this.movecarusel(positionCollection, ".wrapper__carusel");
    };
    document.querySelector(".line__nav__left").onclick = () => {
      positionCollection -= caruselStep;
      if (positionCollection < 0) {
        positionCollection = 0;
      }
      this.movecarusel(positionCollection, ".wrapper__carusel");
    };
  },
};
</script>

<style scoped src="@/assets/css/actor.css"></style>
