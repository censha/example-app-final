<template>
  <main class="poiske main">
    <div class="item">
      <!-- ======= section2 ======= -->
      <section class="section2__section2">
        <div class="section2__wrapper1">
          <h1 class="section2__title">Результаты поиска</h1>
        </div>
      </section>
      <!-- ======= End section2 ======= -->
    </div>
    <div class="item">
      <!-- ======= section3 ======= -->
      <section class="section3__section3">
        <div class="section3__row">
          <div class="item">
            <div class="section3__wrapper6">
              <h4 class="section3__highlights4">Критерии поиска</h4>
              <hr class="section3__line1" size="1" />
              <div class="section3__info4">Оцифровка</div>
              <div class="section3__content_box2">
                <div class="section3__info3">Только оцифрованные</div>
                <div class="spacer"></div>
                <div class="item">
                  <img
                    class="section3__image5"
                    src="@/assets/img/assets/9b3492734757cd2cca719e30fda62fc7.png"
                    alt="alt text"
                  />
                </div>
              </div>
              <div class="section3__info41">Формат</div>
              <div class="section3__wrapper7">
                <a href="#" class="section3__info31">Любой</a>
              </div>
              <div class="section3__flex_row">
                <div class="section3__wrapper8">
                  <a href="#" class="section3__info5">HD и выше</a>
                </div>
                <div class="item">
                  <div class="section3__wrapper81">
                    <a href="#" class="section3__info51">2К и выше</a>
                  </div>
                </div>
              </div>
              <div class="section3__flex_row1">
                <div class="section3__group">
                  <img
                    class="section3__image6"
                    src="@/assets/img/assets/2a95c48b671357d5892a50a24bf5764a.png"
                    alt="alt text"
                  />
                </div>
                <p class="section3__desc1">
                  Возможность оцифровки<br />кинопленки
                </p>
                <div class="item">
                  <img
                    class="section3__icon6"
                    src="@/assets/img/assets/0058c62cf0fd48394f93daccaa53acc8.png"
                    alt="alt text"
                  />
                </div>
              </div>
              <hr class="section3__line11" size="1" />
              <div class="section3__flex_row2">
                <div class="section3__info42">Искать в:</div>
                <div class="spacer"></div>
                <div class="section3__rect14"></div>
              </div>
              <div class="section3__wrapper9">
                <a href="#" class="section3__info52">Полное наименование</a>
              </div>
              <div class="section3__wrapper12">
                <a href="#" class="section3__info32">Название</a>
              </div>
              <div class="section3__wrapper91">
                <a href="#" class="section3__info53">Описание</a>
              </div>
              <div class="section3__wrapper91">
                <a href="#" class="section3__info54">Авторы</a>
              </div>
              <div class="section3__wrapper91">
                <a href="#" class="section3__info55">Студии</a>
              </div>
              <hr class="section3__line11" size="1" />
              <div class="section3__info43">Год выпуска</div>
              <div class="section3__flex_row3">
                <div class="section3__info6">С:</div>
                <div class="item">
                  <input type="text" class="section3__rect10" />
                </div>
                <div class="spacer"></div>
                <div class="section3__info61">По:</div>
                <div class="item">
                  <input type="text" class="section3__rect10" />
                </div>
              </div>
              <div class="section3__info41">Год хроники</div>
              <div class="section3__flex_row3">
                <div class="section3__info6">С:</div>
                <div class="item1">
                  <input type="text" class="section3__rect10" />
                </div>
                <div class="spacer1"></div>
                <div class="section3__info61">По:</div>
                <div class="item1">
                  <input type="text" class="section3__rect10" />
                </div>
              </div>
              <div class="section3__info41">Тип</div>
              <div class="section3__content_box2">
                <div class="section3__info33">Фильм</div>
                <div class="spacer1"></div>
                <div class="item1">
                  <img
                    class="section3__image5"
                    src="@/assets/img/assets/9b3492734757cd2cca719e30fda62fc7.png"
                    alt="alt text"
                  />
                </div>
              </div>
              <hr class="section3__line11" size="1" />
              <div class="section3__info43">Теги</div>
              <button class="section3__btn" onclick="alert(`It is clickable`)">
                <span class="section3__btn__text">Природа</span>
              </button>
              <div class="section3__flex_row5">
                <div class="section3__box">
                  <div class="section3__group1">
                    <div class="section3__info7">Край</div>
                  </div>
                </div>
                <div class="item">
                  <div class="section3__box1">
                    <div class="section3__group1">
                      <div class="section3__info34">Природа</div>
                    </div>
                  </div>
                </div>
              </div>
              <hr class="section3__line11" size="1" />
              <div class="section3__info43">Сортировать по</div>
              <div class="section3__wrapper7">
                <a href="#" class="section3__info35">Дате публикации</a>
              </div>
              <div class="section3__wrapper91">
                <a href="#" class="section3__info56">По году (сначала новые)</a>
              </div>
              <div class="section3__wrapper91">
                <a href="#" class="section3__info57"
                  >По году (сначала старые)</a
                >
              </div>
              <hr class="section3__line11" size="1" />
              <div class="section3__wrapper10">
                <a href="#" class="section3__info8">Применить фильтры</a>
              </div>
              <div class="section3__wrapper11">
                <a href="#" class="section3__info9">Сбросить</a>
              </div>
            </div>
          </div>
          <div class="spacer"></div>
          <div class="item1">
            <div class="section3__col">
              <div
                class="wrapper_header_search"
                style="margin: 0; max-width: unset"
              >
                <!-- <select name="" id="">
            <option value="">Видео</option>
            <option value="">Фото</option>
          </select> -->
                <input type="text" placeholder="Поиск по архиву..." />
                <div class="btn_header_search">
                  <p>Найти</p>
                  <img src="@/assets/img/search_black.svg" alt="" />
                </div>
              </div>
              <div class="section3__col1">
                <h3 class="">
                  <div class="section3__subtitle2">
                    <span class="section3__subtitle2_span0"
                      >Результатов по вашему запросу </span
                    ><span class="section3__subtitle2_span1">5</span>
                  </div>
                </h3>
                <div class="section3__col2">
                  <div class="section3__row1">
                    <div class="item">
                      <div class="section3__col">
                        <div class="item">
                          <div class="section3__content_box1">
                            <img
                              src="@/assets/img/assets/983b900b4541330291d103100c6321e7.png"
                              alt=""
                            />
                            <img
                              class="section3__icon5"
                              style="
                                position: absolute;
                                bottom: 7px;
                                right: 10px;
                                width: 20px;
                              "
                              src="@/assets/img/assets/200bc36971d8fd47a7e06448cf1401b1.png"
                              alt="alt text"
                            />
                          </div>
                        </div>
                        <div class="section3__info2">Название видеофайла</div>
                        <p class="section3__desc">
                          Сюжеты, 1 сюжет,<br />хронометраж: 0:03:24, кат. V3
                        </p>
                      </div>
                    </div>
                    <div class="spacer"></div>
                    <div class="item">
                      <div class="section3__col">
                        <div class="item1">
                          <div class="section3__wrapper5">
                            <img
                              src="@/assets/img/assets/14c0b621bdb08bd3a52c772a5a3bc2c0.png"
                              alt=""
                            />
                            <img
                              class="section3__icon5"
                              style="
                                position: absolute;
                                bottom: 7px;
                                right: 10px;
                                width: 20px;
                              "
                              src="@/assets/img/assets/200bc36971d8fd47a7e06448cf1401b1.png"
                              alt="alt text"
                            />
                          </div>
                        </div>
                        <div class="section3__info2">Название видеофайла</div>
                        <p class="section3__desc">
                          Сюжеты, 1 сюжет,<br />хронометраж: 0:03:24, кат. V3
                        </p>
                      </div>
                    </div>
                    <div class="spacer"></div>
                    <div class="item">
                      <div class="section3__col">
                        <div class="item2">
                          <div class="section3__wrapper5">
                            <img
                              src="@/assets/img/assets/0b6883897ef4b8c99a0f62d66af56b13.png"
                              alt=""
                            />
                            <img
                              class="section3__icon5"
                              style="
                                position: absolute;
                                bottom: 7px;
                                right: 10px;
                                width: 20px;
                              "
                              src="@/assets/img/assets/200bc36971d8fd47a7e06448cf1401b1.png"
                              alt="alt text"
                            />
                          </div>
                        </div>
                        <div class="section3__info2">Название видеофайла</div>
                        <p class="section3__desc">
                          Сюжеты, 1 сюжет,<br />хронометраж: 0:03:24, кат. V3
                        </p>
                      </div>
                    </div>
                    <div class="spacer"></div>
                    <div class="item">
                      <div class="section3__col">
                        <div class="item3">
                          <div class="section3__wrapper5">
                            <img
                              src="@/assets/img/assets/acb0c43d087268d2cf6a74d6af3f8dbc.png"
                              alt=""
                            />
                            <img
                              class="section3__icon5"
                              style="
                                position: absolute;
                                bottom: 7px;
                                right: 10px;
                                width: 20px;
                              "
                              src="@/assets/img/assets/200bc36971d8fd47a7e06448cf1401b1.png"
                              alt="alt text"
                            />
                          </div>
                        </div>
                        <div class="section3__info2">Название видеофайла</div>
                        <p class="section3__desc">
                          Сюжеты, 1 сюжет,<br />хронометраж: 0:03:24, кат. V3
                        </p>
                      </div>
                    </div>
                    <div class="spacer"></div>
                    <div class="item">
                      <div class="section3__col">
                        <div class="item4">
                          <div class="section3__wrapper5">
                            <img
                              src="@/assets/img/assets/ea391f2fb200d8985cbe54f032955ab8.png"
                              alt=""
                            />
                            <img
                              class="section3__icon5"
                              style="
                                position: absolute;
                                bottom: 7px;
                                right: 10px;
                                width: 20px;
                              "
                              src="@/assets/img/assets/200bc36971d8fd47a7e06448cf1401b1.png"
                              alt="alt text"
                            />
                          </div>
                        </div>
                        <div class="section3__info2">Название видеофайла</div>
                        <p class="section3__desc">
                          Сюжеты, 1 сюжет,<br />хронометраж: 0:03:24, кат. V3
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- ======= End section3 ======= -->
    </div>
  </main>
</template>

<script>
export default {
  name: "search-view",
};
</script>

<style scoped src="@/assets/css/Poiske.css">
.section3__rect10 {
  max-width: 50px;
}
</style>

<style>
.section3__rect10 {
  max-width: 50px;
  padding: 0 5px;
}
</style>
