        <template>
            <Header></Header>
  <div class="total_wrapper">
    <div class="wrapper_kinoarhive">
      <h1>Видеоархив</h1>
      <div class="container container--header_search">
        <div class="wrapper_header_search">
          <!-- <select name="" id="">
            <option value="">Видео</option>
            <option value="">Фото</option>
          </select> -->
          <input type="text" placeholder="Поиск по архиву..." />
          <div class="btn_header_search">
            <p>Найти</p>
            <img src="@/assets/img/search_black.svg" alt="" />
          </div>
        </div>
        <div class="pop_up_search hidden">
          <div class="pop_up_search_wrp col-1">
            <ul class="pop_up_search_list">
              По темам:
              <li class="pop_up_search_item">Революция и Ленин</li>
              <li class="pop_up_search_item">Первые годы СССР</li>
              <li class="pop_up_search_item">Первая мировая война</li>
              <li class="pop_up_search_item">Сталинская эпоха</li>
              <li class="pop_up_search_item">Вторая мировая война</li>
              <li class="pop_up_search_item">Оттепель</li>
              <li class="pop_up_search_item">Космос</li>
              <li class="pop_up_search_item">Времена застоя</li>
              <li class="pop_up_search_item">Перестройка</li>
              <li class="pop_up_search_item">Пермь</li>
              <li class="pop_up_search_item">Наука</li>
              <li class="pop_up_search_item">Культура и искусство</li>
              <li class="pop_up_search_item">Спорт</li>
            </ul>
          </div>
          <div class="pop_up_search_wrp col-2">
            <ul class="pop_up_search_list">
              По студиям:
              <li class="pop_up_search_item">ЦСДФ</li>
              <li class="pop_up_search_item">ЦНФ</li>
              <li class="pop_up_search_item">ЛСДФ</li>
              <li class="pop_up_search_item">ЛНФ</li>
              <li class="pop_up_search_item">Свердловская студия</li>
              <li class="pop_up_search_item">Казанская студия</li>
              <li class="pop_up_search_item">Учебные</li>
            </ul>
            <ul class="pop_up_search_list">
              По типам:
              <li class="pop_up_search_item">Фильмы</li>
              <li class="pop_up_search_item">Многосерийные</li>
              <li class="pop_up_search_item">Киножурналы</li>
              <li class="pop_up_search_item">Сюжеты кинохроники</li>
              <li class="pop_up_search_item">Зарубежные сюжеты</li>
              <li class="pop_up_search_item">Телепередачи</li>
              <li class="pop_up_search_item">Рекламные ролики</li>
            </ul>
          </div>
          <div class="pop_up_search_wrp col-3">
            <ul class="pop_up_search_list">
              По категориям:
              <li class="pop_up_search_item">Документальные</li>
              <li class="pop_up_search_item">Научно-популярные</li>
            </ul>
          </div>
        </div>
      </div>

      <div class="kinoarhive__content">
        <div class="kinoarhive__content__filter">
          <h2>Фильтр</h2>
          <div class="decor_line_filter"></div>
          <p>Оцифровка</p>
          <select class="digitise">
            <option value="0">Все</option>
            <option value="1">Только оцифрованные</option>
            <option value="2">Не оцифрованные</option>
          </select>
          <p>Формат</p>
          <div class="wrapper_filter_format">
            <div class="filter_format_blok filter_format_blok1 active">
              <p>Любой</p>
            </div>
            <div class="filter_format_blok filter_format_blok2">
              <p>HD и выше</p>
            </div>
            <div class="filter_format_blok filter_format_blok3">
              <p>2К и выше</p>
            </div>
          </div>
          <p>Год выпуска</p>
          <div class="wrapper_year_filter">
            <p>с:</p>
            <input type="number" class="year1" />
            <p>По:</p>
            <input type="number" class="year2" />
          </div>
          <p>Год хроники</p>
          <div class="wrapper_year_filter">
            <p>с:</p>
            <input type="number" class="year3" />
            <p>По:</p>
            <input type="number" class="year4" />
          </div>
          <p>Тип</p>
          <select class="type_kino">
            <option value="0">Все</option>
            <option value="Фильм">Фильм</option>
            <option value="Видео">Видео</option>
            <option value="Любительское">Любительское</option>
            <option value="Документальный">Документальный</option>
            <option value="Учебный">Учебный</option>
            <option value="Научно-популярный">Научно-популярный</option>
          </select>
          <p>Коллекции</p>
          <select class="collection_kino">
            <option value="0">не выбранно</option>
            <option value="">
              «Новый курс», первая негосударственная киностудия Пермского края
            </option>
            <option value="">Павел Печёнкин: тогда и сейчас</option>
            <option value="">Пермское игровое кино</option>
            <option value="">Проект «Сто поэтов России»</option>
            <option value="">Последние киносъемки в Пермской области</option>
            <option value="">
              «Советский Урал»: сюжеты о Пермской области
            </option>
            <option value="">Кинопутешествия Михаила Заплатина</option>
            <option value="">Золотой век «Пермьтелефильма»</option>
            <option value="">Валерий Горшков, летописец нашего края</option>
            <option value="">Снято кинолюбителями</option>
          </select>
          <p>Темы</p>
          <select class="topic_kino">
            <option value="0">не выбранно</option>
            <option value="">Старая Пермь</option>
            <option value="">Природа нашего края</option>
            <option value="">Пермский балет</option>
            <option value="">Пермские древности</option>
            <option value="">Прикамье спортивное</option>
            <option value="">Великая Отечественная: былое и память</option>
            <option value="">Вплавь по Каме</option>
          </select>
          <p>Теги</p>
          <input type="text" class="filter_tegs" />
          <div class="wrapper_filter_tegs"></div>
          <p>Сортировать по</p>
          <div class="render_filter_block render_filter_block1 active">
            <p>Дате публикации</p>
          </div>
          <div class="render_filter_block render_filter_block2">
            <p>По году (сначала новые)</p>
          </div>
          <div class="render_filter_block render_filter_block3">
            <p>По году (сначала старые)</p>
          </div>
          <div class="decor_line_filter"></div>
          <div class="btn_filter_go">
            <p>Применить фильтры</p>
          </div>
          <div class="btn_filter_clean">
            <p>Сбросить</p>
          </div>
        </div>
        <div class="kinoarhive__content__films">
          <h2>каталог</h2>
          <article>По вашему запросу найдено <span>66</span></article>
          <div class="setting_filter">
            <img src="@/assets/img/filter.svg" alt="" />
          </div>
          <div
            class="wrapper_content_element"
            id="paginated-list"
            aria-live="polite"
          >
          <div v-for="film in films">
            <elem
              class="content_element pag_elem"
              data-digitise="0"
              data-hd="4K"
              data-year1="2000"
              data-year2="2000"
              data-type="Фильм"
              data-callection=""
              data-temps=""
              data-tegs="Авиационная промышленность,Авиация военная,Авиация гражданская"
            >
              <div class="content_element__img">
                <a :href="route('film',[id = film.id])"
                  ><img
                    class="foto_video"
                    :src="(help + film.banner)"
                    alt=""
                /></a>
                <img class="elem_info_img" src="@/assets/img/i.svg" alt="" />
              </div>
              <div class="content_element__info">
                <p>Инаугурация Трутнева</p>
                <article>4K</article>
                <article>хронометраж: <span>0:00:30</span></article>
              </div>
              <div class="content_element__teg">
                <p>Категории:</p>
                <div class="content_element__teg__category">
                  <span>Фильм</span>
                </div>
                <p>Тэги</p>
                <div class="content_element__teg__name">
                  <span>Авиационная промышленность</span>
                  <span>Авиация военная</span>
                  <span>Авиация гражданская</span>
                </div>
              </div>
            </elem>
          </div>

            <elem
              class="content_element pag_elem"
              data-digitise="0"
              data-hd="2K"
              data-year1="2010"
              data-year2="2010"
              data-type="Видео"
              data-callection=""
              data-temps=""
              data-tegs="Балет,Бандформирования,Бартер"
            >
              <div class="content_element__img">
                <a href="kino.html"
                  ><img
                    class="foto_video"
                    src="@/assets/foto_video/2.png"
                    alt=""
                /></a>
                <img class="elem_info_img" src="@/assets/img/i.svg" alt="" />
              </div>
              <div class="content_element__info">
                <p>Молотов</p>
                <article>2K<br />хронометраж: 0:00:30</article>
              </div>
              <div class="content_element__teg">
                <p>Категории:</p>
                <div class="content_element__teg__category">
                  <span>Видео</span>
                </div>
                <p>Тэги</p>
                <div class="content_element__teg__name">
                  <span>Балет</span>
                  <span>Бандформирования</span>
                  <span>Бартер</span>
                </div>
              </div>
            </elem>
            <elem
              class="content_element pag_elem"
              data-digitise="1"
              data-hd="Full HD"
              data-year1="2007"
              data-year2="2007"
              data-type="Фильм"
              data-callection=""
              data-temps=""
              data-tegs="Горная (добывающая) промышленность,Города,Государственные награды"
            >
              <div class="content_element__img">
                <a href="kino.html"
                  ><img
                    class="foto_video"
                    src="@/assets/foto_video/3.png"
                    alt=""
                /></a>
                <img class="elem_info_img" src="@/assets/img/i.svg" alt="" />
              </div>
              <div class="content_element__info">
                <p>PHHG</p>
                <article>Full HD<br />хронометраж: 0:00:30</article>
              </div>
              <div class="content_element__teg">
                <p>Категории:</p>
                <div class="content_element__teg__category">
                  <span>Любительское</span>
                </div>
                <p>Тэги</p>
                <div class="content_element__teg__name">
                  <span>Горная (добывающая) промышленность</span>
                  <span>Города</span>
                  <span>Государственные награды</span>
                </div>
              </div>
            </elem>
            <elem
              class="content_element pag_elem"
              data-digitise="1"
              data-hd="Full HD"
              data-year1="2001"
              data-year2="2001"
              data-type="Видео"
              data-callection=""
              data-temps=""
              data-tegs="Живопись,Животноводство,Журналистика"
            >
              <div class="content_element__img">
                <a href="kino.html"
                  ><img
                    class="foto_video"
                    src="@/assets/foto_video/4.png"
                    alt=""
                /></a>
                <img class="elem_info_img" src="@/assets/img/i.svg" alt="" />
              </div>
              <div class="content_element__info">
                <p>Путин в Перми (2001)</p>
                <article>Full HD<br />хронометраж: 0:00:30</article>
              </div>
              <div class="content_element__teg">
                <p>Категории:</p>
                <div class="content_element__teg__category">
                  <span>Видео</span>
                </div>
                <p>Тэги</p>
                <div class="content_element__teg__name">
                  <span>Живопись</span>
                  <span>Животноводство</span>
                  <span>Журналистика</span>
                </div>
              </div>
            </elem>
            <elem
              class="content_element pag_elem"
              data-digitise="1"
              data-hd="HD"
              data-year1="1990"
              data-year2="1990"
              data-type="Любительское"
              data-callection=""
              data-temps=""
              data-tegs="История,Иудаизм,Киноискусство"
            >
              <div class="content_element__img">
                <a href="kino.html"
                  ><img
                    class="foto_video"
                    src="@/assets/foto_video/5.png"
                    alt=""
                /></a>
                <img class="elem_info_img" src="@/assets/img/i.svg" alt="" />
              </div>
              <div class="content_element__info">
                <p>Титаник в Кристале</p>
                <article>HD<br />хронометраж: 0:00:30</article>
              </div>
              <div class="content_element__teg">
                <p>Категории:</p>
                <div class="content_element__teg__category">
                  <span>Любительское</span>
                </div>
                <p>Тэги</p>
                <div class="content_element__teg__name">
                  <span>История</span>
                  <span>Иудаизм</span>
                  <span>Киноискусство</span>
                </div>
              </div>
            </elem>
            <elem
              class="content_element pag_elem"
              data-digitise="1"
              data-hd="HD"
              data-year1="1995"
              data-year2="1995"
              data-type="Любительское"
              data-callection=""
              data-temps=""
              data-tegs="Лесная целлюлозно-бумажная промышленность,Лесное хозяйство,Литература"
            >
              <div class="content_element__img">
                <a href="kino.html"
                  ><img
                    class="foto_video"
                    src="@/assets/foto_video/6.png"
                    alt=""
                /></a>
                <img class="elem_info_img" src="@/assets/img/i.svg" alt="" />
              </div>
              <div class="content_element__info">
                <p>Зиновьев в Перми</p>
                <article>HD<br />хронометраж: 0:00:30</article>
              </div>
              <div class="content_element__teg">
                <p>Категории:</p>
                <div class="content_element__teg__category">
                  <span>Любительское</span>
                </div>
                <p>Тэги</p>
                <div class="content_element__teg__name">
                  <span>Лесная, целлюлозно-бумажная промышленность</span>
                  <span>Лесное хозяйство</span>
                  <span>Литература</span>
                </div>
              </div>
            </elem>
          </div>
        </div>
      </div>

      <div class="kinoarhive__content__dop">
        <h3>Последние добавленные</h3>
        <div class="wrapper_kinoarhive__content__dop">
          <div class="content_element">
            <div class="content_element__img">
              <img class="foto_video" src="@/assets/foto_video/1.png" alt="" />
              <img class="elem_info_img" src="@/assets/img/i.svg" alt="" />
            </div>
            <div class="content_element__info">
              <p>Инаугурация Трутнева</p>
              <article>4K<br />хронометраж: 0:00:30</article>
            </div>
            <div class="content_element__teg">
              <p>Категории:</p>
              <div class="content_element__teg__category">
                <span>Фильм</span>
              </div>
              <p>Тэги</p>
              <div class="content_element__teg__name">
                <span>Авиационная промышленность</span>
                <span>Авиация военная</span>
                <span>Авиация гражданская</span>
              </div>
            </div>
          </div>
          <div class="content_element">
            <div class="content_element__img">
              <img class="foto_video" src="@/assets/foto_video/2.png" alt="" />
              <img class="elem_info_img" src="@/assets/img/i.svg" alt="" />
            </div>
            <div class="content_element__info">
              <p>Молотов</p>
              <article>2K<br />хронометраж: 0:00:30</article>
            </div>
            <div class="content_element__teg">
              <p>Категории:</p>
              <div class="content_element__teg__category">
                <span>Видео</span>
              </div>
              <p>Тэги</p>
              <div class="content_element__teg__name">
                <span>Балет</span>
                <span>Бандформирования</span>
                <span>Бартер</span>
              </div>
            </div>
          </div>
          <div class="content_element">
            <div class="content_element__img">
              <img class="foto_video" src="@/assets/foto_video/3.png" alt="" />
              <img class="elem_info_img" src="@/assets/img/i.svg" alt="" />
            </div>
            <div class="content_element__info">
              <p>PHHG</p>
              <article>FullHd<br />хронометраж: 0:00:30</article>
            </div>
            <div class="content_element__teg">
              <p>Категории:</p>
              <div class="content_element__teg__category">
                <span>Любительское</span>
              </div>
              <p>Тэги</p>
              <div class="content_element__teg__name">
                <span>Горная (добывающая) промышленность</span>
                <span>Города</span>
                <span>Государственные награды</span>
              </div>
            </div>
          </div>
          <div class="content_element">
            <div class="content_element__img">
              <img class="foto_video" src="@/assets/foto_video/4.png" alt="" />
              <img class="elem_info_img" src="@/assets/img/i.svg" alt="" />
            </div>
            <div class="content_element__info">
              <p>Путин в Перми (2001)</p>
              <article>FullHd<br />хронометраж: 0:00:30</article>
            </div>
            <div class="content_element__teg">
              <p>Категории:</p>
              <div class="content_element__teg__category">
                <span>Видео</span>
              </div>
              <p>Тэги</p>
              <div class="content_element__teg__name">
                <span>Живопись</span>
                <span>Животноводство</span>
                <span>Журналистика</span>
              </div>
            </div>
          </div>
          <div class="content_element">
            <div class="content_element__img">
              <img class="foto_video" src="@/assets/foto_video/5.png" alt="" />
              <img class="elem_info_img" src="@/assets/img/i.svg" alt="" />
            </div>
            <div class="content_element__info">
              <p>Титаник в Кристале</p>
              <article>HD<br />хронометраж: 0:00:30</article>
            </div>
            <div class="content_element__teg">
              <p>Категории:</p>
              <div class="content_element__teg__category">
                <span>Любительское</span>
              </div>
              <p>Тэги</p>
              <div class="content_element__teg__name">
                <span>История</span>
                <span>Иудаизм</span>
                <span>Киноискусство</span>
              </div>
            </div>
          </div>
          <div class="content_element">
            <div class="content_element__img">
              <img class="foto_video" src="@/assets/foto_video/6.png" alt="" />
              <img class="elem_info_img" src="@/assets/img/i.svg" alt="" />
            </div>
            <div class="content_element__info">
              <p>Зиновьев в Перми</p>
              <article>HD<br />хронометраж: 0:00:30</article>
            </div>
            <div class="content_element__teg">
              <p>Категории:</p>
              <div class="content_element__teg__category">
                <span>Любительское</span>
              </div>
              <p>Тэги</p>
              <div class="content_element__teg__name">
                <span>Лесная, целлюлозно-бумажная промышленность</span>
                <span>Лесное хозяйство</span>
                <span>Литература</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <Footer></Footer>
</template>

<script>
import Header from "@/Layouts/Header.vue";
import Footer from "@/Layouts/Footer.vue";

export default {
  name: "kino-archive-view",
  components: {
        Header,
        Footer,
    },
    props:[
    'films',
    ]
};
</script>

<style scoped src="@/assets/css/kinoarhive.css"></style>
