<template>

<div>
    <Header></Header>
    <main class="total_wrapper" style="margin-top: 50px">
    <div class="breadcrumbs" style="margin-bottom: 30px">
      <a style="font-weight: 500; font-size: 12px; color: #878787" href="/"
        >Главная > </a
      ><a style="font-weight: 500; font-size: 12px; color: #ffffff" href="#"
        >Личный кабинет</a
      >
    </div>

    <div class="row" style="display: flex">
      <div class="col-md-2">
        <div class="img-profile-wrap">
          <img class="profile_img" src="@/assets/img/img_profile.png" alt="" />
          <button class="profile_edit_btn">Редактировать профиль</button>
        </div>
      </div>
      <div class="col-md-6" style="margin-left: 30px">
        <p class="name_profile">{{user.first_name}}<br />{{user.last_name}}</p>
        <p class="about_profile">Текст описание "О себе"</p>
      </div>
    </div>

    <div class="tabs">
      <input type="radio" name="tab-btn" id="tab-btn-1" value="" checked />
      <label for="tab-btn-1">Коллекции</label>
      <input type="radio" name="tab-btn" id="tab-btn-2" value="" />
      <label for="tab-btn-2">Заказы</label>

      <input type="radio" name="tab-btn" id="tab-btn-4" value="" />
      <label for="tab-btn-4">Обратная связь</label>
      <div id="content-1">
        <div class="wrapper__carusel wrapper__carusel__collection">
          <div class="carusel__line carusel_line_collection">
            <a href="/film_card" class=""
              ><div class="carusel__block">
                <img src="@/assets/foto/foto0013.jpg" alt="" />
                <div class="carusel__block__name">
                  <p>
                    «Новый курс», первая негосударственная киностудия Пермского
                    края
                  </p>
                </div>
              </div></a
            ><a href="/film_card" class=""
              ><div class="carusel__block">
                <img src="@/assets/foto/foto0014.jpg" alt="" />
                <div class="carusel__block__name">
                  <p>Павел Печёнкин: тогда и сейчас</p>
                </div>
              </div></a
            ><a href="/film_card" class=""
              ><div class="carusel__block">
                <img src="@/assets/foto/foto0015.jpg" alt="" />
                <div class="carusel__block__name">
                  <p>Пермское игровое кино</p>
                </div>
              </div></a
            >
            <a href="/film_card" class=""
              ><div class="add-carusel-block">
                <p
                  style="
                    font-size: 70px;
                    line-height: 42px;
                    color: #d9d9d9;
                    margin-bottom: 10px;
                  "
                >
                  +
                </p>
                <p
                  style="
                    font-weight: 600;
                    font-size: 16px;
                    line-height: 20px;
                    color: #ffffff;
                  "
                >
                  Создать альбом
                </p>
              </div></a
            >
          </div>
        </div>
      </div>
      <div id="content-2">Содержимое 2...</div>

      <div id="content-4">Содержимое 4...</div>
    </div>
  </main>
    <Footer></Footer>
</div>


</template>

<script>

import Header from "@/Layouts/Header.vue";
import Footer from "@/Layouts/Footer.vue";

export default {
  name: "personal-view",
  components: {
        Header,
        Footer,
    },
    props:[
    'user'
    ],
};
</script>

<style scoped>
.tabs {
  font-size: 0;
  margin-top: 30px;
}

.tabs > input[type="radio"] {
  display: none;
}

.tabs > div {
  /* скрыть контент по умолчанию */
  display: none;
  /* border: 1px solid #e0e0e0; */
  padding: 20px 0px;
  font-size: 16px;
}

/* отобразить контент, связанный с вабранной радиокнопкой (input type="radio") */
#tab-btn-1:checked ~ #content-1,
#tab-btn-2:checked ~ #content-2,
#tab-btn-3:checked ~ #content-3,
#tab-btn-4:checked ~ #content-4 {
  display: block;
}

.tabs > label {
  display: inline-block;
  text-align: center;
  vertical-align: middle;
  user-select: none;
  background-color: transparent;
  padding-bottom: 10px;
  margin-right: 100px;
  transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out;
  cursor: pointer;
  position: relative;
  top: 1px;
  border-bottom: 3px solid transparent;

  font-weight: 600;
  font-size: 20px;
  line-height: 24px;
  color: #f3f3f4;
}

.tabs > label:not(:first-of-type) {
  border-left: none;
}

.tabs > input[type="radio"]:checked + label {
  background-color: transparent;
  color: #df8e75;
  border-bottom: 3px solid #df8e75;
}
.name_profile {
  font-family: "Montserrat";
  font-style: normal;
  font-weight: 700;
  font-size: 20px;
  line-height: 24px;
  color: #ffffff;
}
.about_profile {
  font-family: "Montserrat";
  font-style: normal;
  font-weight: 500;
  font-size: 16px;
  line-height: 20px;
  color: #ffffff;
  margin-top: 20px;
}
.profile_edit_btn {
  background: #d9d9d9;
  box-shadow: 0px 4px 13px rgba(0, 0, 0, 0.25);
  border-radius: 3px;
  font-weight: 600;
  font-size: 10px;
  line-height: 12px;
  text-align: center;
  color: #4a4a4d;
  padding: 6px 12px;
  margin-top: 10px;
}

.profile_img {
  background: #d9d9d9;
  border-radius: 6px;
  max-width: 170px;
}
.img-profile-wrap {
  background: #3e3e3e;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  border-radius: 6px;
  padding: 10px;
  display: flex;
  flex-flow: column;
}
.wrapper__carusel {
  border-top: none;
}
.add-carusel-block {
  height: 100%;
  width: 285px;
  background: #2c2c30;
  border: 1px dashed #d9d9d9;
  display: flex;
  flex-flow: column;
  align-items: center;
  justify-content: center;
}
</style>
<style scoped src="@/assets/css/index.css"></style>
