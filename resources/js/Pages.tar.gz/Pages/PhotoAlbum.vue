<template>
    <Header></Header>
  <div class="total_wrapper">
    <div class="wrapper__foto">
      <div class="wraperr__foto__img">
        <img :src="(help + photocollection.banner)" alt="" />
        <p>{{photocollection.name}}</p>
        <article>описание фотоколлекции</article>
      </div>
      <div class="wraperr__foto__btns">
        <div class="foto__btn__pay">
          <p>Приобрести</p>
        </div>
        <div class="foto__btn__favourites">
          <p>В избранное</p>
          <img src="@/assets/img/flag.svg" alt="" />
        </div>
        <div class="foto__type">
          <img src="@/assets/img/fail.svg" alt="" />
          <p>Тип файла: Jpg</p>
        </div>
      </div>
    </div>
    <!-- <div class="wrapper__avtor">
      <p>Автор: <span>UserName</span></p>
    </div> -->
    <h2>Другие фото альбома</h2>
    <div class="wrapper__other_foto">
      <div v-for="photo in photos" class="other_foto__elem">
        <a :href="route('photo', photo.id)"><img :src="(help + photo.photo)" :alt="photo.name" /></a>
      </div>
    </div>
  </div>
  <Footer></Footer>
</template>

<script>
import "@/assets/css/foto.css";
import Header from "@/Layouts/Header.vue";
import Footer from "@/Layouts/Footer.vue";
import help from "@/Components/helper-api";

export default {
  name: "photo-view",
  props:[
    'photos',
    'photocollection'
    ],
  components: {
        Header,
        Footer,
    },
};
</script>

<style></style>
