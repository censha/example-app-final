<script setup>
import Checkbox from '@/Components/Checkbox.vue';
import GuestLayout from '@/Layouts/GuestLayout.vue';
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import PrimaryButton from '@/Components/PrimaryButton.vue';
import TextInput from '@/Components/TextInput.vue';
import { Head, Link, useForm } from '@inertiajs/inertia-vue3';

defineProps({
    canResetPassword: Boolean,
    status: String,
});

const form = useForm({
    email: '',
    password: '',
    remember: false,
});

const submit = () => {
    form.post(route('login'), {
        onFinish: () => form.reset('password'),
    });
};
</script>

<template>
    <Header></Header>
    <div class="wrapper__login">
    <div class="wrapper__enter__login">
      <div class="enter__login__nav">
        <p data-tab="enter__login__enter" class="active">Вход</p>
        <Link :href="route('register')"><p data-tab="enter__login__registr">Регистрация</p></Link>
      </div>
      <form @submit.prevent="submit">
          <div class="enter__login__enter active">
            <input type="text"  v-model="form.email" placeholder="Введите E-mail" />
            <input type="text"  v-model="form.password" placeholder="Введите пароль" />
            <div class="remember_pass">
                <p>Забыли пароль?</p>
            </div>
            <button style="display: block; margin: 0 auto;" class="btn__login__enter" :disabled="form.processing">
               Войти
                <!-- <PrimaryButton class="ml-4" :class="{ 'opacity-25': form.processing }" >
                    Log in
                </PrimaryButton> -->
            </button>
        </div>
    </form>
    </div>
  </div>
    <!-- <GuestLayout>
        <Head title="Log in" />

        <div v-if="status" class="mb-4 font-medium text-sm text-green-600">
            {{ status }}
        </div>


                <InputError class="mt-2" :message="form.errors.password" />
            </div>

            <div class="block mt-4">
                <label class="flex items-center">
                    <Checkbox name="remember" v-model:checked="form.remember" />
                    <span class="ml-2 text-sm text-gray-600">Remember me</span>
                </label>
            </div>

            <div class="flex items-center justify-end mt-4">
                <Link
                    v-if="canResetPassword"
                    :href="route('password.request')"
                    class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                    Forgot your password?
                </Link>

    </GuestLayout> -->
    <Footer></Footer>
</template>

<script>
import "@/assets/css/login.css";

import Header from "@/Layouts/Header.vue";
import Footer from "@/Layouts/Footer.vue";

export default {
    name: "Login-component",
    name: "App",
    components: {
        Header,
        Footer,
    },
    

};
</script>
