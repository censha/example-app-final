<template>
    <Header></Header>
    <div class="wrapper__login">
        <div class="wrapper__enter__login">
            <div class="enter__login__nav">
                <Link :href="route('login')"><p data-tab="enter__login__enter">Вход</p></Link>
                <p data-tab="enter__login__registr" class="active">Регистрация</p>
            </div>
            <form @submit.prevent="submit">
                <div class="enter__login__registr active">
                    <input type="text" v-model="form.first_name" placeholder="Имя" />
                    <input type="text" v-model="form.last_name" placeholder="Фамилия" />
                    <input type="text" v-model="form.email" placeholder="Введите E-mail" />
                    <input type="text" v-model="form.password" placeholder="Введите пароль" />
                    <input type="text" v-model="form.password_confirmation" placeholder="Повторите пароль" />
                    <button style="display: block; margin: 0 auto;" class="btn__login__registr" :disabled="form.processing">
                        <!-- <PrimaryButton class="ml-4" :class="{ 'opacity-25': form.processing }" >
                        Register
                        </PrimaryButton> -->
                        Регистрация
                    </button>
                </div>
            </form>
        </div>
    </div>
    <Footer></Footer>
</template>

<script setup>
import GuestLayout from '@/Layouts/GuestLayout.vue';
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import PrimaryButton from '@/Components/PrimaryButton.vue';
import TextInput from '@/Components/TextInput.vue';
import { Head, Link, useForm } from '@inertiajs/inertia-vue3';

const form = useForm({
    first_name: '',
    last_name: '',
    email: '',
    password: '',
    password_confirmation: '',
    terms: false,
});

const submit = () => {
    form.post(route('register'), {
        onFinish: () => form.reset('password', 'password_confirmation'),
    });
};
</script>


<script>
import "@/assets/css/login.css";

import Header from "@/Layouts/Header.vue";
import Footer from "@/Layouts/Footer.vue";

export default {
    name: "Login-component",
    name: "App",
    components: {
        Header,
        Footer,
    },

};


</script>

