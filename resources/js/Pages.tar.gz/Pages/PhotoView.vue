<template>
    <Header></Header>
  <div class="total_wrapper">
    <div class="wrapper__foto">
      <div class="wraperr__foto__img">
        <img src="@/assets/foto/foto0010.jpg" alt="" />
        <p>Название</p>
        <article>описание фото</article>
      </div>
      <div class="wraperr__foto__btns">
        <div class="foto__btn__pay">
          <p>Приобрести</p>
        </div>
        <div class="foto__btn__favourites">
          <p>В избранное</p>
          <img src="@/assets/img/flag.svg" alt="" />
        </div>
        <div class="foto__type">
          <img src="@/assets/img/fail.svg" alt="" />
          <p>Тип файла: Jpg</p>
        </div>
      </div>
    </div>
    <div class="wrapper__avtor">
      <p>Автор: <span>UserName</span></p>
    </div>
    <h2>Другие фото автора</h2>
    <div class="wrapper__other_foto">
      <div class="other_foto__elem">
        <a href="#"><img src="@/assets/foto/foto0011.jpg" alt="" /></a>
      </div>
      <div class="other_foto__elem">
        <a href="#"><img src="@/assets/foto/foto0011.jpg" alt="" /></a>
      </div>
      <div class="other_foto__elem">
        <a href="#"><img src="@/assets/foto/foto0011.jpg" alt="" /></a>
      </div>
      <div class="other_foto__elem">
        <a href="#"><img src="@/assets/foto/foto0011.jpg" alt="" /></a>
      </div>
      <div class="other_foto__elem">
        <a href="#"><img src="@/assets/foto/foto0011.jpg" alt="" /></a>
      </div>
    </div>
  </div>
  <Footer></Footer>
</template>

<script>
import "@/assets/css/foto.css";
import Header from "@/Layouts/Header.vue";
import Footer from "@/Layouts/Footer.vue";

export default {
  name: "photo-view",
  components: {
        Header,
        Footer,
    },
};
</script>

<style></style>
