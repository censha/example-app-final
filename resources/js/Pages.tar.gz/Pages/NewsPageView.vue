<template>
    <Header></Header>
  <div class="total_wrapper">
    <div class="wrapper_news">
      <div class="news_img">
        <img :src="(help + news.photo_news)" alt="" />
        <h1>{{news.name}}</h1>
      </div>
      <div class="wrapper_news__text">
        <div class="news__text">
            {{news.content}}
        </div>
        <div class="other_news">
          <h3>Другие новости</h3>
          <div class="other_news__block">
            <img src="@/assets/img/blog2.png" alt="" />
            <p>Центральная студия документальных фильмов</p>
            <article>
              Центральная студия документальных фильмов (ЦСДФ) являлась
              флагманом документального кино...
            </article>
          </div>
          <div class="other_news__block">
            <img src="@/assets/img/blog2.png" alt="" />
            <p>Центральная студия документальных фильмов</p>
            <article>
              Центральная студия документальных фильмов (ЦСДФ) являлась
              флагманом документального кино...
            </article>
          </div>
          <div class="other_news__block">
            <img src="@/assets/img/blog2.png" alt="" />
            <p>Центральная студия документальных фильмов</p>
            <article>
              Центральная студия документальных фильмов (ЦСДФ) являлась
              флагманом документального кино...
            </article>
          </div>
        </div>
      </div>
    </div>
  </div>
  <Footer></Footer>
</template>

<script>
import Header from "@/Layouts/Header.vue";
import Footer from "@/Layouts/Footer.vue";
import help from "@/Components/helper-api";
export default {
  name: "news-page-view",
  props:[
    'news'
    ],
    components: {
        Header,
        Footer,
    },
};
</script>

<style scoped src="@/assets/css/news.css"></style>
