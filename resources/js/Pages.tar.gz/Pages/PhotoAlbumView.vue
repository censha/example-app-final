<template>
    <Header></Header>
    <main class="photoo main">
    <div class="item">
      <!-- ======= section2 ======= -->
      <section class="section2__section2">
        <h1 class="section2__hero_title">Фото</h1>
      </section>
      <!-- ======= End section2 ======= -->
    </div>
    <div class="item">
      <!-- ======= section3 ======= -->
      <section class="section3__section3">
        <div class="section3__wrapper1">
          <input
            style="width: 100%;"
            type="text"
            class="text_search"
            placeholder="Поиск по архиву..."
            data-v-9ea40744=""
          />
          <div class="section3__content_box">
            <h5 class="section3__highlights2">Найти</h5>
            <div class="item">
              <img
                class="section3__icon4"
                src="../assets/img/assets/6a4fe2bdb7e4b66e55ea8752612d69c0.png"
                alt="alt text"
              />
            </div>
          </div>
        </div>
        <div class="section3__flex_row">
          <div class="item">
            <h1 class="section3__title">Новые альбомы</h1>
          </div>
          <div class="spacer"></div>
          <div class="item1">
            <img
              class="section3__image7"
              src="../assets/img/assets/30b93ca82564d395e6deeaa0be13dd77.png"
              alt="alt text"
            />
          </div>
        </div>
        <hr class="section3__line1" size="1" />
        <div class="section3__flex_row1">
          <div v-for="photocollection in photocollections" class="item">
            <a :href="route('photoalbums', photocollection.id)"
            class="section3__wrapper3">
              <div class="item">
                <img
                  class="section3__image6"
                  :src="help + photocollection.banner"
                  alt="alt text"
                />
              </div>
              <div class="section3__text1">{{photocollection.name}}</div>
            </a>
          </div>

        </div>
      </section>
      <!-- ======= End section3 ======= -->
    </div>
    <div class="item">
      <!-- ======= section4 ======= -->
      <section class="section4__section4">
        <div class="section4__col">
          <div class="section4__row">
            <div class="item">
              <h1 class="section4__title">Избранные альбомы</h1>
            </div>
            <div class="spacer"></div>
            <div class="item1">
              <div class="section4__wrapper7">
                <a href="#" class="section4__highlights5">Все альбомы</a>
              </div>
            </div>
          </div>
          <div class="section4__col1">
            <div class="section4__row1">
              <div class="item">
                <a href="#" class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </a>
              </div>
              <div class="spacer"></div>
              <div class="item">
                <div class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </div>
              </div>
              <div class="spacer1"></div>
              <div class="item">
                <div class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </div>
              </div>
              <div class="spacer2"></div>
              <div class="item">
                <div class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </div>
              </div>
              <div class="spacer1"></div>
              <div class="item">
                <div class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </div>
              </div>
              <div class="spacer"></div>
              <div class="item">
                <div class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </div>
              </div>
            </div>
            <div class="section4__row2">
              <div class="item">
                <div class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </div>
              </div>
              <div class="spacer"></div>
              <div class="item">
                <div class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </div>
              </div>
              <div class="spacer"></div>
              <div class="item">
                <div class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </div>
              </div>
              <div class="spacer1"></div>
              <div class="item">
                <div class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </div>
              </div>
              <div class="spacer"></div>
              <div class="item">
                <div class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </div>
              </div>
              <div class="spacer"></div>
              <div class="item">
                <div class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </div>
              </div>
            </div>
            <div class="section4__row2">
              <div class="item1">
                <div class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </div>
              </div>
              <div class="spacer2"></div>
              <div class="item1">
                <div class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </div>
              </div>
              <div class="spacer3"></div>
              <div class="item1">
                <div class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </div>
              </div>
              <div class="spacer4"></div>
              <div class="item1">
                <div class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </div>
              </div>
              <div class="spacer3"></div>
              <div class="item1">
                <div class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </div>
              </div>
              <div class="spacer2"></div>
              <div class="item1">
                <div class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </div>
              </div>
            </div>
            <div class="section4__row2">
              <div class="item2">
                <div class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </div>
              </div>
              <div class="spacer5"></div>
              <div class="item2">
                <div class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </div>
              </div>
              <div class="spacer5"></div>
              <div class="item2">
                <div class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </div>
              </div>
              <div class="spacer6"></div>
              <div class="item2">
                <div class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </div>
              </div>
              <div class="spacer5"></div>
              <div class="item2">
                <div class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </div>
              </div>
              <div class="spacer5"></div>
              <div class="item2">
                <div class="section4__wrapper5">
                  <img
                    class="section4__wrapper6"
                    src="../assets/img/assets/6e149f16a354e6d9d3d8166cffb90757.png"
                  />
                  <div class="section4__info2">Название альбома</div>
                </div>
              </div>
            </div>
            <div class="section4__row3">
              <a href="#" class="item">
                <img
                  class="section4__image4"
                  src="../assets/img/assets/81fbcfff32ecd99ceb98d24781495915.png"
                  alt="alt text"
                />
              </a>
              <div class="spacer"></div>
              <a href="#" class="item1">
                <img
                  class="section4__image5"
                  src="../assets/img/assets/25bfeb06b7d6a8783db87384ad645d76.png"
                  alt="alt text"
                />
              </a>
              <div class="spacer"></div>
              <a href="#" class="section4__subtitle1">1</a>
              <a href="#" class="section4__subtitle2">2</a>
              <a href="#" class="section4__subtitle2">3</a>
              <a href="#" class="section4__subtitle21">4</a>
              <h3 class="section4__subtitle21">...</h3>
              <a href="#" class="section4__subtitle22">16</a>
              <div class="spacer"></div>
              <a href="#" class="item1">
                <img
                  class="section4__image5"
                  src="../assets/img/assets/4e5ce117df73b37964344a8e896d073d.png"
                  alt="alt text"
                />
              </a>
              <div class="spacer"></div>
              <a href="#" class="item">
                <img
                  class="section4__image4"
                  src="../assets/img/assets/8253bdda278388ee236f678e6c766cd4.png"
                  alt="alt text"
                />
              </a>
            </div>
          </div>
        </div>
      </section>
      <!-- ======= End section4 ======= -->
    </div>
  </main>
  <Footer></Footer>
</template>

<script>

import "@/assets/css/index.css";
import Header from "@/Layouts/Header.vue";
import Footer from "@/Layouts/Footer.vue";
import help from "@/Components/helper-api";
export default {
  name: "photo-album-view",
  name: "Login-component",
    name: "App",

    props:[
    'photos',
    'photocollections'
    ],
    components: {
        Header,
        Footer,
    },
};
</script>

<style scoped src="@/assets/css/Photoo.css"></style>
