<script setup>
import { Head, Link, useForm } from '@inertiajs/inertia-vue3';


// const form = useForm({
//     name: '',
//     email: '',
//     password: '',
//     password_confirmation: '',
//     terms: false,
// });
</script>

<template>
    <Header></Header>
  <div class="total_wrapper">
    <div class="wrapper_kino">
      <div class="kino__img">
        <img :src="(help + film.banner)" :alt="film.video_name " />
      </div>
      <div class="wrapper-kino__name">
        <div class="kino__name">
          <p><br />({{film.year_movie}})</p>
        </div>
        <div class="kino__load">
          <!-- <select>
                        <option value="1">Full HD</option>
                        <option value="2">2k</option>
                        <option value="3">4k</option>
                    </select> -->
          <!-- <div class="btn__cut_video">
            <p>Обрезать фрагмент</p>
          </div> -->
          <div class="btn__download_video">
            <p>Скачать фильм</p>
          </div>
        </div>
        <div class="kino__info">
          <div class="btn__favourites_video">
            <p>Добавить в избранное</p>
            <img src="@/assets/img/flag.svg" alt="" />
          </div>
          <p>Авторы:</p>
          <div class="wrappers-avtors_film">
            <div class="avtors_film_block">
              <p>Режиссер:</p>
              <a href="actor.html"><span>К. Константинов</span></a>
            </div>
            <div class="avtors_film_block">
              <p>Оператор:</p>
              <a href="actor.html"><span>К. Константинов</span></a>
            </div>
            <div class="avtors_film_block">
              <p>Сценарист:</p>
              <a href="actor.html"><span>К. Константинов</span></a>
            </div>
            <div class="avtors_film_block">
              <p>В главных ролях:</p>
              <span>К. Константинов</span><span>К. Константинов</span
              ><span>К. Константинов</span><span>К. Константинов</span
              ><span>К. Константинов</span><span>К. Константинов</span>
            </div>
          </div>
        </div>
      </div>

      <div class="wrapper_player_film">
        <div class="player_film">
          <p>Описание:</p>
          <article>
            Проект «Великая война» рассказывает о наиболее значимых событиях и
            сражениях Великой Отечественной войны.
          </article>
          <div class="wrapper__info__film">
            <div class="info__film__elem">
              <p>Шифр/номер:</p>
              <article>{{film.shifr}}</article>
            </div>
            <div class="info__film__elem">
              <p>Страна производства: </p>
              <article>{{film.copyright_holder}}</article>
            </div>
            <div class="info__film__elem">
              <p>Язык оригинала:</p>
              <article>{{film.orig_lang}}</article>
            </div>
            <div class="info__film__elem">
              <p>Вид фильма:</p>
              <article>{{film.type_movie}}</article>
            </div>
            <div class="info__film__elem">
              <p>Альтернативные названия:</p>
              <article>{{film.alt_name}}</article>
            </div>
            <div class="info__film__elem">
              <p>Вид материала к фильму:</p>
              <article>{{film.type_material_movie}}</article>
            </div>
            <div class="info__film__elem">
              <p>Латинская транскрипция названия:</p>
              <article>{{film.lat_trans_name}}</article>
            </div>
            <div class="info__film__elem">
              <p>Жанр фильма:</p>
              <article>{{film.genre_movie}}</article>
            </div>
            <div class="info__film__elem">
              <p>Серия:</p>
              <article>{{film.num_in_seria}}</article>
            </div>
            <div class="info__film__elem">
              <p>Темы:</p>
              <article>{{film.topic_movie}}</article>
            </div>
            <div class="info__film__elem">
              <p>Вариант фильма:</p>
              <article>Авторская версия</article>
            </div>
            <div class="info__film__elem">
              <p>Ключевые слова:</p>
              <article>{{film.tag}}</article>
            </div>
            <div class="info__film__elem">
              <p>Год съемки:</p>
              <article>2010</article>
            </div>
            <div class="info__film__elem">
              <p>Хронометраж:</p>
              <article>{{film.genre_movie}}</article>
            </div>
            <div class="info__film__elem">
              <p>Прокатное удостоверение:</p>
              <article>--</article>
            </div>
            <div class="info__film__elem">
              <p>Кол-во серий:</p>
              <article>{{film.how_series}}</article>
            </div>
            <div class="info__film__elem">
              <p>Даты выпуска:</p>
              <article>2010</article>
            </div>
            <div class="info__film__elem">
              <p>Правообладатель:</p>
              <article>{{film.copyright_holder}}</article>
            </div>
            <div class="info__film__elem">
              <p>Студия производитель:</p>
              <article>FilmStudio</article>
            </div>
            <div class="info__film__elem">
              <p>Звук:</p>
              <article>{{film.sound}}</article>
            </div>
            <div class="info__film__elem">
              <p>Компания прокатчик:</p>
              <article>Название компании</article>
            </div>
            <div class="info__film__elem">
              <p>Цветность:</p>
              <article>{{film.chroma}}</article>
            </div>
          </div>
          <h2>Великая война (2010 – 2012)</h2>
          <video-player ref="vvv" :options="videoOptions" @duration="changeDuration"/>
      <MultiRangeSlider
      :min="0"
      :max="duration"
      :step="0.1"
      :ruler="true"
      :label="true"
      :minValue="min"
      :maxValue= "max"
      @input="UpdateValues"
    />
          <div class="decor_line"></div>
          <div class="wrapper__tegs">
            <div class="tegs__elem">
              <p>Теги</p>
            </div>
            <div class="tegs__elem">
              <p>Теги</p>
            </div>
            <div class="tegs__elem">
              <p>Теги</p>
            </div>
            <div class="tegs__elem">
              <p>Теги</p>
            </div>
            <div class="tegs__elem">
              <p>Теги</p>
            </div>
            <div class="tegs__elem">
              <p>Теги</p>
            </div>
          </div>
        </div>
        <div class="over_film">
          <h4>Похожее</h4>
          <div class="over_film__elem">
            <img src="@/assets/img/i1.png" alt="" />
            <p>Название видеофайла</p>
          </div>
          <div class="over_film__elem">
            <img src="@/assets/img/i1.png" alt="" />
            <p>Название видеофайла</p>
          </div>
          <div class="over_film__elem">
            <img src="@/assets/img/i1.png" alt="" />
            <p>Название видеофайла</p>
          </div>
          <div class="over_film__elem">
            <img src="@/assets/img/i1.png" alt="" />
            <p>Название видеофайла</p>
          </div>
        </div>
      </div>

      <section>
        <h2>Афиша фильма</h2>
        <div class="decor_line"></div>
        <img class="afishaimg" src="@/assets/img/afisha.png" alt="" />
        <img class="afishaimg" src="@/assets/img/afisha.png" alt="" />
        <!-- <p>Афиш нет</p> -->
      </section>
      <div class="modal_afisha">
        <article>&times;</article>
        <div class="modal_afisha__img">
          <img class="afishaimg" src="@/assets/img/afisha.png" alt="" />
        </div>
        <div class="modal_afisha__text">
          <p>Афиша <span>12 Стульев</span></p>
          <p>Фильм <span>12 Стульев</span></p>
          <p>Художники <span>И. Иванов, П. Петров, С. Сидоров</span></p>
          <p>Тираж <span>123456789</span></p>
          <p>Размеры, см <span>1500x70</span></p>
        </div>
      </div>
    </div>
    <section>
      <h2>Аудио материалы</h2>
      <div class="decor_line"></div>
      <div class="wrapper_audio">
        <div class="wrapper_elem_audio">
          <audio controls src="@/assets/audio/audio1.mp3"></audio>
          <p>Название Аудио</p>
        </div>
        <div class="wrapper_elem_audio">
          <audio controls src="@/assets/audio/audio1.mp3"></audio>
          <p>Название Аудио</p>
        </div>

        <!-- <p>Аудио нет</p> -->
      </div>
    </section>

    <div class="block_comment">
      <div class="total_wrapper">
        <h2>Комментарии</h2>
        <div class="block_comment__new">
          <p>Оставьте ваш комментарий</p>
          <div class="wrapper_comment__new__text">
            <textarea placeholder="Текст комментария"></textarea>
            <div class="btn__comm">
              <p>Отправить</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <Footer></Footer>
</template>

<script>


import "@/assets/css/kino.css";
import Header from "@/Layouts/Header.vue";
import Footer from "@/Layouts/Footer.vue";
import help from "@/Components/helper-api";
import VideoPlayer from '@/components/VideoPlayer.vue';
import 'video.js/dist/video-js.css';
import MultiRangeSlider from "multi-range-slider-vue";

export default {
  name: "Film-card-view",
  name: "App",
    components: {
        Header,
        Footer,
        VideoPlayer,
        MultiRangeSlider
    },
    props:[
        'film'
    ],
    data() {
      return {
        min:0,
        max:0,
        duration: 1,
        videoOptions: {
          autoplay: false,
          controls: true,
          sources: [
            {
              src: this.film.prefix + '/' + this.film.file_path + '/' +  this.film.file_name,
                type: 'video/mp4'
            }
          ]
        }
      };
    },
    methods:{
        changeDuration(d){
            console.log("D", d);
            this.duration = d || 1;
        },
        UpdateValues(x){
            console.log("NEW", x);
        }
    },
    mounted() {
    let allAfishs = document.querySelectorAll(".afishaimg");
    for (let elem of allAfishs) {
      elem.onclick = () => {
        document.querySelector(".modal_afisha").classList.add("active");
      };
    }
    document.querySelector(".modal_afisha article").onclick = () => {
      document.querySelector(".modal_afisha").classList.remove("active");
    };
  },
};
</script>

<style></style>
