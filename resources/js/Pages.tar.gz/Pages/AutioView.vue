<template>
  <main class="audio main">
    <div class="item">
      <!-- ======= section2 ======= -->
      <section class="section2__section2">
        <div class="section2__flex_row">
          <div class="item">
            <div class="section2__group">
              <img
                class="section2__image5"
                src="../assets/img/assets/a7f6a8537114ee9c50e8a7a0f3bdd458.png"
                alt="alt text"
              />
            </div>
          </div>
          <div class="spacer"></div>
          <div class="item1">
            <div class="section2__flex_column">
              <h2 class="section2__medium_title">Название аудиодорожки</h2>
              <div class="section2__flex_row1">
                <div class="item">
                  <div
                    class="section2__group1"
                    style="
                      --src: url(.../assets/img/assets/d5e72a515b63d523de822a23e8a5f935.png);
                    "
                  >
                    <img
                      class="section2__image6"
                      src="../assets/img/assets/cf39f8a1998f7f347f0eb66e7dcea703.png"
                      alt="alt text"
                    />
                  </div>
                </div>
                <div class="spacer"></div>
                <div class="item1">
                  <img
                    class="section2__image8"
                    src="../assets/img/assets/c60fd309bd0696617afed568a33e0cf9.png"
                    alt="alt text"
                  />
                </div>
                <div class="spacer1"></div>
                <div class="item1">
                  <img
                    class="section2__image7"
                    src="../assets/img/assets/ffba014e1f8215f6d73b36e918ec953f.png"
                    alt="alt text"
                  />
                </div>
                <div class="spacer2"></div>
                <div class="item2">
                  <div class="section2__flex_column1">
                    <div class="item">
                      <img
                        class="section2__image4"
                        src="../assets/img/assets/3a86640e3d002dc3e906b2920b70a69d.png"
                        alt="alt text"
                      />
                    </div>
                    <div class="section2__group2">
                      <div class="section2__rect6"></div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="section2__flex_row2">
                <div class="item">
                  <h5 class="section2__highlights2">03:06</h5>
                </div>
                <div class="spacer"></div>
                <div class="item">
                  <h5 class="section2__highlights2">06:45</h5>
                </div>
              </div>
              <div class="section2__group3">
                <div class="section2__rect11"></div>
              </div>
            </div>
          </div>
        </div>
        <hr class="section2__line2" size="1" />
        <div class="section2__flex_row3">
          <div class="item">
            <div class="section2__flex_column2">
              <div class="section2__flex_row4">
                <div class="section2__box">
                  <div class="section2__group4">
                    <div class="section2__text">Теги</div>
                  </div>
                </div>
                <div class="spacer"></div>
                <div class="section2__box">
                  <div class="section2__group4">
                    <div class="section2__text">Теги</div>
                  </div>
                </div>
                <div class="spacer"></div>
                <div class="section2__box">
                  <div class="section2__group4">
                    <div class="section2__text">Теги</div>
                  </div>
                </div>
                <div class="spacer"></div>
                <div class="section2__box">
                  <div class="section2__group4">
                    <div class="section2__text">Теги</div>
                  </div>
                </div>
                <div class="spacer"></div>
                <div class="section2__box">
                  <div class="section2__group4">
                    <div class="section2__text">Теги</div>
                  </div>
                </div>
                <div class="spacer"></div>
                <div class="section2__box">
                  <div class="section2__group4">
                    <div class="section2__text">Теги</div>
                  </div>
                </div>
              </div>
              <div class="section2__flex_row5">
                <div
                  class="section2__wrapper5"
                  style="
                    --src: url(.../assets/img/assets/697ba6dacc9264462b4c0f9231302744.png);
                  "
                ></div>
                <div class="spacer"></div>
                <h5 class="">
                  <div class="section2__highlights3">
                    <span class="section2__highlights3_span0">Автор:</span
                    ><span class="section2__highlights3_span1"> UserName</span>
                  </div>
                </h5>
              </div>
              <h3 class="section2__subtitle3">Описание</h3>
              <h5 class="section2__highlights31">
                Описание аудиофайла если есть
              </h5>
            </div>
          </div>
          <div class="spacer"></div>
          <div class="item1">
            <div class="section2__flex_column3">
              <div class="section2__wrapper7">
                <h5 class="section2__highlights5">Приобрести</h5>
              </div>
              <div class="section2__wrapper6">
                <h5 class="section2__highlights4">В избранное</h5>
                <div class="spacer"></div>
                <div class="item">
                  <img
                    class="section2__image9"
                    src="../assets/img/assets/740e5e8b907af5b63fc4c2a889aac3a4.png"
                    alt="alt text"
                  />
                </div>
              </div>
              <div class="section2__flex_row6">
                <div class="item">
                  <img
                    class="section2__image10"
                    src="../assets/img/assets/2e5ee86b2c6635096352cb93dd1364bb.png"
                    alt="alt text"
                  />
                </div>
                <div class="spacer"></div>
                <h5 class="">
                  <div class="section2__highlights32">
                    <span class="section2__highlights32_span0">Тип файла:</span
                    ><span class="section2__highlights32_span1"> Mp3</span>
                  </div>
                </h5>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- ======= End section2 ======= -->
    </div>
    <div class="item">
      <!-- ======= section3 ======= -->
      <section class="section3__section3">
        <h1 class="section3__hero_title">Похожие Аудио</h1>
      </section>
      <!-- ======= End section3 ======= -->
    </div>
    <div class="item">
      <!-- ======= section4 ======= -->
      <section class="section4__section4">
        <hr class="section4__line1" size="1" />
        <div class="section4__flex_row7">
          <div class="item">
            <div class="section4__flex_column4">
              <div class="section4__wrapper1">
                <div class="item">
                  <img
                    class="section4__image3"
                    src="../assets/img/assets/071ca7e97ddd8c742f6cccbcea095420.png"
                    alt="alt text"
                  />
                </div>
                <div class="spacer"></div>
                <div class="item1">
                  <div class="section4__group">
                    <img
                      class="section4__image2"
                      src="../assets/img/assets/e17e5c06e40dc9dd3226b08a0a894ba2.png"
                      alt="alt text"
                    />
                  </div>
                </div>
                <div class="spacer1"></div>
                <div class="item2">
                  <div class="section4__flex_column5">
                    <h3 class="section4__subtitle2">Название аудиодорожки 1</h3>
                    <div class="section4__flex_row8">
                      <h5 class="section4__highlights2">
                        Краткое описание аудиодорожки
                      </h5>
                      <div class="spacer"></div>
                      <h5 class="section4__highlights21">06:45</h5>
                    </div>
                    <div class="section4__wrapper2"></div>
                  </div>
                </div>
                <div class="spacer"></div>
                <div class="item3">
                  <div class="section4__flex_column6">
                    <div class="item">
                      <img
                        class="section4__image4"
                        src="../assets/img/assets/3a86640e3d002dc3e906b2920b70a69d.png"
                        alt="alt text"
                      />
                    </div>
                    <div class="section4__group1">
                      <div class="section4__rect6"></div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="section4__wrapper3">
                <div class="item">
                  <img
                    class="section4__image3"
                    src="../assets/img/assets/071ca7e97ddd8c742f6cccbcea095420.png"
                    alt="alt text"
                  />
                </div>
                <div class="spacer"></div>
                <div class="item1">
                  <div class="section4__group">
                    <img
                      class="section4__image2"
                      src="../assets/img/assets/e17e5c06e40dc9dd3226b08a0a894ba2.png"
                      alt="alt text"
                    />
                  </div>
                </div>
                <div class="spacer1"></div>
                <div class="item2">
                  <div class="section4__flex_column5">
                    <h3 class="section4__subtitle2">Название аудиодорожки 2</h3>
                    <div class="section4__flex_row8">
                      <h5 class="section4__highlights2">
                        Краткое описание аудиодорожки
                      </h5>
                      <div class="spacer1"></div>
                      <h5 class="section4__highlights21">06:45</h5>
                    </div>
                    <div class="section4__wrapper2"></div>
                  </div>
                </div>
                <div class="spacer"></div>
                <div class="item3">
                  <div class="section4__flex_column6">
                    <div class="item1">
                      <img
                        class="section4__image4"
                        src="../assets/img/assets/3a86640e3d002dc3e906b2920b70a69d.png"
                        alt="alt text"
                      />
                    </div>
                    <div class="section4__group1">
                      <div class="section4__rect6"></div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="section4__wrapper3">
                <div class="item4">
                  <img
                    class="section4__image3"
                    src="../assets/img/assets/071ca7e97ddd8c742f6cccbcea095420.png"
                    alt="alt text"
                  />
                </div>
                <div class="spacer2"></div>
                <div class="item5">
                  <div class="section4__group">
                    <img
                      class="section4__image2"
                      src="../assets/img/assets/e17e5c06e40dc9dd3226b08a0a894ba2.png"
                      alt="alt text"
                    />
                  </div>
                </div>
                <div class="spacer3"></div>
                <div class="item6">
                  <div class="section4__flex_column5">
                    <h3 class="section4__subtitle2">Название аудиодорожки 3</h3>
                    <div class="section4__flex_row8">
                      <h5 class="section4__highlights2">
                        Краткое описание аудиодорожки
                      </h5>
                      <div class="spacer2"></div>
                      <h5 class="section4__highlights21">06:45</h5>
                    </div>
                    <div class="section4__wrapper2"></div>
                  </div>
                </div>
                <div class="spacer2"></div>
                <div class="item7">
                  <div class="section4__flex_column6">
                    <div class="item2">
                      <img
                        class="section4__image4"
                        src="../assets/img/assets/3a86640e3d002dc3e906b2920b70a69d.png"
                        alt="alt text"
                      />
                    </div>
                    <div class="section4__group1">
                      <div class="section4__rect6"></div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="section4__wrapper3">
                <div class="item8">
                  <img
                    class="section4__image3"
                    src="../assets/img/assets/071ca7e97ddd8c742f6cccbcea095420.png"
                    alt="alt text"
                  />
                </div>
                <div class="spacer4"></div>
                <div class="item9">
                  <div class="section4__group">
                    <img
                      class="section4__image2"
                      src="../assets/img/assets/e17e5c06e40dc9dd3226b08a0a894ba2.png"
                      alt="alt text"
                    />
                  </div>
                </div>
                <div class="spacer5"></div>
                <div class="item10">
                  <div class="section4__flex_column5">
                    <h3 class="section4__subtitle2">Название аудиодорожки 4</h3>
                    <div class="section4__flex_row8">
                      <h5 class="section4__highlights2">
                        Краткое описание аудиодорожки
                      </h5>
                      <div class="spacer3"></div>
                      <h5 class="section4__highlights21">06:45</h5>
                    </div>
                    <div class="section4__wrapper2"></div>
                  </div>
                </div>
                <div class="spacer4"></div>
                <div class="item11">
                  <div class="section4__flex_column6">
                    <div class="item3">
                      <img
                        class="section4__image4"
                        src="../assets/img/assets/3a86640e3d002dc3e906b2920b70a69d.png"
                        alt="alt text"
                      />
                    </div>
                    <div class="section4__group1">
                      <div class="section4__rect6"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="spacer"></div>
          <div class="item1">
            <div class="section4__wrapper4">
              <div class="section4__rect8"></div>
            </div>
          </div>
        </div>
      </section>
      <!-- ======= End section4 ======= -->
    </div>
  </main>
</template>

<script>
export default {
  name: "audio-view",
};
</script>

<style scoped>
.main {
  display: flex;
  flex-direction: column;
  background-color: #242427;
  position: relative;
  overflow: hidden;
  margin-top: 100px;
}

.main > .item {
  display: flex;
  flex-direction: column;
  position: relative;
}

.section2__section2 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex-grow: 1;
}

.section2__flex_row {
  display: flex;
  width: 75%;
  position: relative;
  margin: 27px auto 0px;
}
@media (max-width: 1399px) {
  .section2__flex_row {
    flex-wrap: wrap;
    justify-content: flex-start;
    align-content: flex-start;
    -moz-column-gap: 0px;
    column-gap: 0px;
    row-gap: 16px;
    width: 80%;
  }
}
@media (max-width: 1199px) {
  .section2__flex_row {
    width: 84.21%;
  }
}
@media (max-width: 991px) {
  .section2__flex_row {
    width: 87.67%;
  }
}
@media (max-width: 767px) {
  .section2__flex_row {
    width: 90.46%;
  }
}
@media (max-width: 575px) {
  .section2__flex_row {
    width: 92.67%;
  }
}
@media (max-width: 479px) {
  .section2__flex_row {
    width: 94.4%;
  }
}
@media (max-width: 383px) {
  .section2__flex_row {
    width: 95.74%;
  }
}

.section2__flex_row > .item {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 183px;
}
@media (max-width: 1399px) {
  .section2__flex_row > .item {
    flex: 0 0 100%;
  }
}

.section2__group {
  display: flex;
  flex-direction: column;
  background-color: #242427;
  position: relative;
  flex-grow: 1;
}

.section2__image5 {
  width: 121px;
  height: auto;
  vertical-align: top;
  -o-object-fit: contain;
  object-fit: contain;
  -o-object-position: center top;
  object-position: center top;
  position: relative;
  min-width: 121px;
  margin: 37px 31px 35px;
}
@media (max-width: 1199px) {
  .section2__image5 {
    margin: 37px 24px 35px;
  }
}
@media (max-width: 991px) {
  .section2__image5 {
    margin: 37px 20px 35px;
  }
}
@media (max-width: 767px) {
  .section2__image5 {
    margin: 37px 16px 35px;
  }
}
@media (max-width: 383px) {
  .section2__image5 {
    margin: 37px 12px 35px;
  }
}

.section2__flex_row > .spacer {
  flex: 0 1 23px;
}
@media (max-width: 1399px) {
  .section2__flex_row > .spacer {
    display: none;
  }
}

.section2__flex_row > .item1 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 913px;
}
@media (max-width: 1399px) {
  .section2__flex_row > .item1 {
    flex: 0 0 100%;
  }
}

.section2__flex_column {
  display: flex;
  flex-direction: column;
  position: relative;
  flex-grow: 1;
}

.section2__medium_title {
  font: 600 25px/1.39 "Montserrat", Helvetica, Arial, serif;
  color: white;
  letter-spacing: 0px;
  position: relative;
}
@media (max-width: 1199px) {
  .section2__medium_title {
    font-size: 20px;
    text-align: left;
  }
}
@media (max-width: 767px) {
  .section2__medium_title {
    font-size: 16px;
  }
}

.section2__flex_row1 {
  display: flex;
  position: relative;
  margin: 15px 0px 0px;
}
@media (max-width: 767px) {
  .section2__flex_row1 {
    flex-wrap: wrap;
    justify-content: flex-start;
    align-content: flex-start;
    -moz-column-gap: 0px;
    column-gap: 0px;
    row-gap: 16px;
  }
}

.section2__flex_row1 > .item {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 58px;
}
@media (max-width: 767px) {
  .section2__flex_row1 > .item {
    flex: 0 0 100%;
  }
}

.section2__group1 {
  display: flex;
  flex-direction: column;
  background: var(--src) center center/cover no-repeat;
  position: relative;
  flex-grow: 1;
}

.section2__image6 {
  width: 20px;
  height: auto;
  vertical-align: top;
  -o-object-fit: contain;
  object-fit: contain;
  -o-object-position: center top;
  object-position: center top;
  position: relative;
  min-width: 20px;
  margin: 18px 16px 18px 22px;
}
@media (max-width: 1199px) {
  .section2__image6 {
    margin: 18px 12px 18px 16px;
  }
}
@media (max-width: 767px) {
  .section2__image6 {
    margin: 18px 8px 18px 12px;
  }
}
@media (max-width: 479px) {
  .section2__image6 {
    margin: 18px 8px;
  }
}

.section2__flex_row1 > .spacer {
  flex: 0 1 20px;
}
@media (max-width: 767px) {
  .section2__flex_row1 > .spacer {
    display: none;
  }
}

.section2__flex_row1 > .item1 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 17px;
}
@media (max-width: 767px) {
  .section2__flex_row1 > .item1 {
    flex: 0 0 100%;
  }
}

.section2__image8 {
  width: 17px;
  height: auto;
  vertical-align: top;
  -o-object-fit: contain;
  object-fit: contain;
  -o-object-position: center top;
  object-position: center top;
  position: relative;
  min-width: 17px;
  margin: 20px 0px;
}

.section2__flex_row1 > .spacer1 {
  flex: 0 1 25px;
}
@media (max-width: 767px) {
  .section2__flex_row1 > .spacer1 {
    display: none;
  }
}

.section2__image7 {
  border-radius: 1px 1px 1px 1px;
  width: 17px;
  height: auto;
  vertical-align: top;
  -o-object-fit: contain;
  object-fit: contain;
  -o-object-position: center top;
  object-position: center top;
  position: relative;
  min-width: 17px;
  margin: 20px 0px;
}

.section2__flex_row1 > .spacer2 {
  flex: 0 1 43px;
}
@media (max-width: 767px) {
  .section2__flex_row1 > .spacer2 {
    display: none;
  }
}

.section2__flex_row1 > .item2 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 91px;
}
@media (max-width: 767px) {
  .section2__flex_row1 > .item2 {
    flex: 0 0 100%;
  }
}

.section2__flex_column1 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex-grow: 1;
  margin: 11px 0px 12px;
}

.section2__flex_column1 > .item {
  display: flex;
  flex-direction: column;
  position: relative;
}

.section2__image4 {
  width: 19px;
  height: auto;
  vertical-align: top;
  -o-object-fit: contain;
  object-fit: contain;
  -o-object-position: center top;
  object-position: center top;
  position: relative;
  min-width: 19px;
  margin: 0px 36px;
}
@media (max-width: 1199px) {
  .section2__image4 {
    margin: 0px 28px;
  }
}
@media (max-width: 991px) {
  .section2__image4 {
    margin: 0px 24px;
  }
}
@media (max-width: 767px) {
  .section2__image4 {
    margin: 0px 20px;
  }
}
@media (max-width: 479px) {
  .section2__image4 {
    margin: 0px 16px;
  }
}

.section2__group2 {
  display: flex;
  flex-direction: column;
  background-color: #56565c;
  position: relative;
  margin: 11px 0px 0px;
}

.section2__rect6 {
  background-color: #f3f3f4;
  height: 4px;
  position: relative;
  margin: 0px 29px 0px 0px;
}
@media (max-width: 1199px) {
  .section2__rect6 {
    margin: 0px 24px 0px 0px;
  }
}
@media (max-width: 991px) {
  .section2__rect6 {
    margin: 0px 20px 0px 0px;
  }
}
@media (max-width: 767px) {
  .section2__rect6 {
    margin: 0px 16px 0px 0px;
  }
}
@media (max-width: 479px) {
  .section2__rect6 {
    margin: 0px 12px 0px 0px;
  }
}

.section2__flex_row2 {
  display: flex;
  position: relative;
  margin: 35px 0px 0px;
}
@media (max-width: 767px) {
  .section2__flex_row2 {
    flex-wrap: wrap;
    justify-content: flex-start;
    align-content: flex-start;
    -moz-column-gap: 0px;
    column-gap: 0px;
    row-gap: 16px;
  }
}

.section2__flex_row2 > .item {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 0 auto;
  min-width: 44px;
}
@media (max-width: 767px) {
  .section2__flex_row2 > .item {
    flex: 0 0 100%;
    min-width: unset;
  }
}

.section2__highlights2 {
  font: 400 16px/1.39 "Montserrat", Helvetica, Arial, serif;
  color: white;
  letter-spacing: 0px;
  position: relative;
  flex-grow: 1;
}
@media (max-width: 1199px) {
  .section2__highlights2 {
    font-size: 12px;
    text-align: left;
  }
}

.section2__flex_row2 > .spacer {
  flex: 0 1 825px;
}
@media (max-width: 767px) {
  .section2__flex_row2 > .spacer {
    display: none;
  }
}

.section2__group3 {
  display: flex;
  flex-direction: column;
  background-color: #56565c;
  position: relative;
  margin: 13px 1px 0px 0px;
}

.section2__rect11 {
  background-color: #f3f3f4;
  width: 38.93%;
  height: 4px;
  position: relative;
  margin: 0px 61.07% 0px 0%;
}

.section2__line2 {
  background-color: #a1a1a1;
  width: 49.56%;
  height: 1px;
  position: relative;
  margin: 20px 37.94% 0px 12.5%;
}

.section2__flex_row3 {
  display: flex;
  width: 75%;
  position: relative;
  margin: 9px auto 100px;
}
@media (max-width: 991px) {
  .section2__flex_row3 {
    flex-wrap: wrap;
    justify-content: flex-start;
    align-content: flex-start;
    -moz-column-gap: 0px;
    column-gap: 0px;
    row-gap: 16px;
    width: 87.67%;
  }
}
@media (max-width: 1399px) {
  .section2__flex_row3 {
    width: 80%;
  }
}
@media (max-width: 1199px) {
  .section2__flex_row3 {
    width: 84.21%;
  }
}
@media (max-width: 767px) {
  .section2__flex_row3 {
    width: 90.46%;
  }
}
@media (max-width: 575px) {
  .section2__flex_row3 {
    width: 92.67%;
  }
}
@media (max-width: 479px) {
  .section2__flex_row3 {
    width: 94.4%;
  }
}
@media (max-width: 383px) {
  .section2__flex_row3 {
    width: 95.74%;
  }
}

.section2__flex_row3 > .item {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 308px;
}
@media (max-width: 991px) {
  .section2__flex_row3 > .item {
    flex: 0 0 100%;
  }
}

.section2__flex_column2 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex-grow: 1;
  margin: 0px 0px 20px;
}

.section2__flex_row4 {
  display: flex;
  position: relative;
}

.section2__box {
  display: flex;
  flex-direction: column;
  border-radius: 3px 3px 3px 3px;
  outline: 1px solid #d9d9d9;
  outline-offset: -1px;
  position: relative;
  flex: 0 1 43px;
}

.section2__group4 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex-grow: 1;
  margin: 3px 5px;
}

.section2__text {
  font: 400 14px/1.21 "Montserrat", Helvetica, Arial, serif;
  color: #d9d9d9;
  letter-spacing: 0px;
  position: relative;
  flex-grow: 1;
}

.section2__flex_row4 > .spacer {
  flex: 0 1 10px;
}

.section2__flex_row5 {
  display: flex;
  position: relative;
  margin: 20px 0px 0px;
}

.section2__wrapper5 {
  display: flex;
  flex-direction: column;
  background: var(--src) center center/cover no-repeat;
  height: 34px;
  position: relative;
  flex: 0 1 34px;
}

.section2__flex_row5 > .spacer {
  flex: 0 1 10px;
}

.section2__highlights3 {
  margin: 7px 0px;
  font: 500 16px/1.25 "Montserrat", Helvetica, Arial, serif;
  color: white;
  letter-spacing: -0.1px;
  position: relative;
  flex: 0 0 auto;
  min-width: 144px;
}
@media (max-width: 1199px) {
  .section2__highlights3 {
    font-size: 12px;
    text-align: left;
  }
}

.section2__highlights3_span0 {
  font: 500 1em/1.25 "Montserrat", Helvetica, Arial, serif;
  color: white;
  font-style: normal;
  letter-spacing: 0px;
}

.section2__highlights3_span1 {
  font: 1em/1.25 "Montserrat", Helvetica, Arial, serif;
  color: white;
  font-style: normal;
  letter-spacing: 0px;
}

.section2__subtitle3 {
  font: 600 20px/1.2 "Montserrat", Helvetica, Arial, serif;
  color: #df8e75;
  letter-spacing: 0px;
  position: relative;
  margin: 10px 0px 0px;
}
@media (max-width: 1199px) {
  .section2__subtitle3 {
    font-size: 16px;
    text-align: left;
  }
}

.section2__highlights31 {
  font: 500 16px/1.25 "Montserrat", Helvetica, Arial, serif;
  color: white;
  letter-spacing: 0px;
  position: relative;
  margin: 5px 25px 0px 0px;
}
@media (max-width: 1199px) {
  .section2__highlights31 {
    font-size: 12px;
    text-align: left;
    margin: 5px 20px 0px 0px;
  }
}
@media (max-width: 991px) {
  .section2__highlights31 {
    margin: 5px 16px 0px 0px;
  }
}
@media (max-width: 575px) {
  .section2__highlights31 {
    margin: 5px 12px 0px 0px;
  }
}

.section2__flex_row3 > .spacer {
  flex: 0 1 526px;
}
@media (max-width: 991px) {
  .section2__flex_row3 > .spacer {
    display: none;
  }
}

.section2__flex_row3 > .item1 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 285px;
}
@media (max-width: 991px) {
  .section2__flex_row3 > .item1 {
    flex: 0 0 100%;
  }
}

.section2__flex_column3 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex-grow: 1;
}

.section2__wrapper7 {
  display: flex;
  flex-direction: column;
  background-color: #df8e75;
  position: relative;
}

.section2__highlights5 {
  display: flex;
  justify-content: center;
  font: 600 16px/1.25 "Montserrat", Helvetica, Arial, serif;
  color: #18181a;
  text-align: center;
  letter-spacing: 0px;
  width: 107px;
  position: relative;
  flex-grow: 1;
  min-width: 107px;
  margin: 15px auto;
}
@media (max-width: 1199px) {
  .section2__highlights5 {
    font-size: 12px;
    text-align: center;
  }
}

.section2__wrapper6 {
  display: flex;
  border-radius: 3px 3px 3px 3px;
  outline: 2px solid #f3f3f4;
  outline-offset: -2px;
  position: relative;
  margin: 17px 0px 0px;
}

.section2__highlights4 {
  display: flex;
  justify-content: flex-end;
  font: 600 16px/1.25 "Montserrat", Helvetica, Arial, serif;
  color: #f3f3f4;
  text-align: right;
  letter-spacing: 0px;
  position: relative;
  flex: 0 0 auto;
  min-width: 110px;
  margin: 15px 0px 15px 75px;
}
@media (max-width: 1199px) {
  .section2__highlights4 {
    font-size: 12px;
    text-align: right;
    margin: 15px 0px 15px 64px;
  }
}
@media (max-width: 991px) {
  .section2__highlights4 {
    margin: 15px 0px 15px 52px;
  }
}
@media (max-width: 767px) {
  .section2__highlights4 {
    margin: 15px 0px 15px 40px;
  }
}
@media (max-width: 575px) {
  .section2__highlights4 {
    margin: 15px 0px 15px 36px;
  }
}
@media (max-width: 479px) {
  .section2__highlights4 {
    margin: 15px 0px 15px 28px;
  }
}

.section2__wrapper6 > .spacer {
  flex: 0 1 10px;
}

.section2__wrapper6 > .item {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 0 1 90px;
}

.section2__image9 {
  width: 16px;
  height: auto;
  filter: drop-shadow(0px 1px 3px rgba(0, 0, 0, 0.247));
  vertical-align: top;
  -o-object-fit: contain;
  object-fit: contain;
  -o-object-position: center top;
  object-position: center top;
  position: relative;
  min-width: 16px;
  margin: 16px 74px 16px 0px;
}
@media (max-width: 1199px) {
  .section2__image9 {
    margin: 16px 60px 16px 0px;
  }
}
@media (max-width: 991px) {
  .section2__image9 {
    margin: 16px 48px 16px 0px;
  }
}
@media (max-width: 767px) {
  .section2__image9 {
    margin: 16px 40px 16px 0px;
  }
}
@media (max-width: 575px) {
  .section2__image9 {
    margin: 16px 36px 16px 0px;
  }
}
@media (max-width: 479px) {
  .section2__image9 {
    margin: 16px 28px 16px 0px;
  }
}

.section2__flex_row6 {
  display: flex;
  position: relative;
  margin: 14px 8px 0px;
}
@media (max-width: 1199px) {
  .section2__flex_row6 {
    margin: 14px 4px 0px;
  }
}

.section2__flex_row6 > .item {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 0 1 19px;
}

.section2__image10 {
  width: 19px;
  height: auto;
  vertical-align: top;
  -o-object-fit: contain;
  object-fit: contain;
  -o-object-position: center top;
  object-position: center top;
  position: relative;
  min-width: 19px;
}

.section2__flex_row6 > .spacer {
  flex: 0 1 18px;
}

.section2__highlights32 {
  margin: 3px 0px 2px;
  font: 500 16px/1.25 "Montserrat", Helvetica, Arial, serif;
  color: white;
  letter-spacing: 0px;
  position: relative;
  flex: 0 0 auto;
  min-width: 132px;
}
@media (max-width: 1199px) {
  .section2__highlights32 {
    font-size: 12px;
    text-align: left;
  }
}

.section2__highlights32_span0 {
  font: 500 1em/1.25 "Montserrat", Helvetica, Arial, serif;
  color: white;
  font-style: normal;
  letter-spacing: 0px;
}

.section2__highlights32_span1 {
  font: 1em/1.25 "Montserrat", Helvetica, Arial, serif;
  color: white;
  font-style: normal;
  letter-spacing: 0px;
}

.section3__section3 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex-grow: 1;
}

.section3__hero_title {
  font: 600 40px/1.39 "Montserrat", Helvetica, Arial, serif;
  color: white;
  letter-spacing: -0.9px;
  width: 20.44%;
  position: relative;
  flex-grow: 1;
  margin: 0px 67.06% 0px 12.5%;
}
@media (max-width: 1199px) {
  .section3__hero_title {
    font-size: 36px;
    text-align: left;
  }
}
@media (max-width: 991px) {
  .section3__hero_title {
    font-size: 32px;
  }
}
@media (max-width: 767px) {
  .section3__hero_title {
    font-size: 28px;
  }
}
@media (max-width: 575px) {
  .section3__hero_title {
    font-size: 24px;
  }
}
@media (max-width: 383px) {
  .section3__hero_title {
    font-size: 20px;
  }
}

.section4__section4 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex-grow: 1;
}

.section4__line1 {
  background-color: #d9d9d9;
  width: 75%;
  height: 1px;
  position: relative;
  margin: 20px auto 0px;
}
@media (max-width: 1399px) {
  .section4__line1 {
    width: 80%;
  }
}
@media (max-width: 1199px) {
  .section4__line1 {
    width: 84.21%;
  }
}
@media (max-width: 991px) {
  .section4__line1 {
    width: 87.67%;
  }
}
@media (max-width: 767px) {
  .section4__line1 {
    width: 90.46%;
  }
}
@media (max-width: 575px) {
  .section4__line1 {
    width: 92.67%;
  }
}
@media (max-width: 479px) {
  .section4__line1 {
    width: 94.4%;
  }
}
@media (max-width: 383px) {
  .section4__line1 {
    width: 95.74%;
  }
}

.section4__flex_row7 {
  display: flex;
  width: 75%;
  position: relative;
  margin: 15px auto 0px;
}
@media (max-width: 1399px) {
  .section4__flex_row7 {
    flex-wrap: wrap;
    justify-content: flex-start;
    align-content: flex-start;
    -moz-column-gap: 0px;
    column-gap: 0px;
    row-gap: 16px;
    width: 80%;
  }
}
@media (max-width: 1199px) {
  .section4__flex_row7 {
    width: 84.21%;
  }
}
@media (max-width: 991px) {
  .section4__flex_row7 {
    width: 87.67%;
  }
}
@media (max-width: 767px) {
  .section4__flex_row7 {
    width: 90.46%;
  }
}
@media (max-width: 575px) {
  .section4__flex_row7 {
    width: 92.67%;
  }
}
@media (max-width: 479px) {
  .section4__flex_row7 {
    width: 94.4%;
  }
}
@media (max-width: 383px) {
  .section4__flex_row7 {
    width: 95.74%;
  }
}

.section4__flex_row7 > .item {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 1170px;
}
@media (max-width: 1399px) {
  .section4__flex_row7 > .item {
    flex: 0 0 100%;
  }
}

.section4__flex_column4 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex-grow: 1;
  margin: 14px 0px 0px;
}

.section4__wrapper1 {
  display: flex;
  background-color: #313134;
  position: relative;
}
@media (max-width: 1399px) {
  .section4__wrapper1 {
    flex-wrap: wrap;
    justify-content: flex-start;
    align-content: flex-start;
    -moz-column-gap: 0px;
    column-gap: 0px;
    row-gap: 16px;
  }
}

.section4__wrapper1 > .item {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 146px;
}
@media (max-width: 1399px) {
  .section4__wrapper1 > .item {
    flex: 0 0 calc(50% - 8px);
  }
}
@media (max-width: 1199px) {
  .section4__wrapper1 > .item {
    flex: 0 0 100%;
  }
}

.section4__image3 {
  width: calc(100% - 9px);
  height: auto;
  vertical-align: top;
  -o-object-fit: contain;
  object-fit: contain;
  -o-object-position: center top;
  object-position: center top;
  position: relative;
  margin: 19px 0px 19px 9px;
}
@media (max-width: 1199px) {
  .section4__image3 {
    width: calc(100% - 18px);
    margin: 19px 9px;
  }
}
@media (max-width: 991px) {
  .section4__image3 {
    width: calc(100% - 8px);
    margin: 19px 4px;
  }
}

.section4__wrapper1 > .spacer {
  flex: 0 1 20px;
}
@media (max-width: 1399px) {
  .section4__wrapper1 > .spacer {
    display: flex;
    flex: 0 0 16px;
  }
}
@media (max-width: 1199px) {
  .section4__wrapper1 > .spacer {
    display: none;
  }
}

.section4__wrapper1 > .item1 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 78px;
}
@media (max-width: 1399px) {
  .section4__wrapper1 > .item1 {
    flex: 0 0 calc(50% - 8px);
  }
}
@media (max-width: 1199px) {
  .section4__wrapper1 > .item1 {
    flex: 0 0 100%;
  }
}

.section4__group {
  display: flex;
  flex-direction: column;
  background-color: #242427;
  position: relative;
  flex-grow: 1;
  margin: 9px 0px;
}

.section4__image2 {
  width: 52px;
  height: auto;
  vertical-align: top;
  -o-object-fit: contain;
  object-fit: contain;
  -o-object-position: center top;
  object-position: center top;
  position: relative;
  min-width: 52px;
  margin: 16px 13px 15px;
}
@media (max-width: 1199px) {
  .section4__image2 {
    margin: 16px 8px 15px;
  }
}
@media (max-width: 575px) {
  .section4__image2 {
    margin: 16px 4px 15px;
  }
}

.section4__wrapper1 > .spacer1 {
  flex: 0 1 20px;
}
@media (max-width: 1399px) {
  .section4__wrapper1 > .spacer1 {
    display: none;
  }
}

.section4__wrapper1 > .item2 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 775px;
}
@media (max-width: 1399px) {
  .section4__wrapper1 > .item2 {
    flex: 0 0 calc(50% - 8px);
  }
}
@media (max-width: 1199px) {
  .section4__wrapper1 > .item2 {
    flex: 0 0 100%;
  }
}

.section4__flex_column5 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex-grow: 1;
  margin: 6px 0px 19px;
}

.section4__subtitle2 {
  font: 600 20px/1.39 "Montserrat", Helvetica, Arial, serif;
  color: white;
  letter-spacing: 0px;
  position: relative;
}
@media (max-width: 1199px) {
  .section4__subtitle2 {
    font-size: 16px;
    text-align: left;
  }
}

.section4__flex_row8 {
  display: flex;
  position: relative;
  margin: 3px 0px 0px;
}

.section4__highlights2 {
  font: 400 16px/1.39 "Montserrat", Helvetica, Arial, serif;
  color: white;
  letter-spacing: 0px;
  position: relative;
  flex: 0 0 auto;
  min-width: 283px;
}
@media (max-width: 1199px) {
  .section4__highlights2 {
    font-size: 12px;
    text-align: left;
  }
}

.section4__flex_row8 > .spacer {
  flex: 0 1 448px;
}

.section4__highlights21 {
  font: 400 16px/1.39 "Montserrat", Helvetica, Arial, serif;
  color: white;
  letter-spacing: 0px;
  position: relative;
  flex: 0 0 auto;
  min-width: 44px;
}
@media (max-width: 1199px) {
  .section4__highlights21 {
    font-size: 12px;
    text-align: left;
  }
}

.section4__wrapper2 {
  display: flex;
  flex-direction: column;
  background-color: #56565c;
  height: 4px;
  position: relative;
  margin: 13px 0px 0px 1px;
}

.section4__wrapper1 > .item3 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 111px;
}
@media (max-width: 1399px) {
  .section4__wrapper1 > .item3 {
    flex: 0 0 calc(50% - 8px);
  }
}
@media (max-width: 1199px) {
  .section4__wrapper1 > .item3 {
    flex: 0 0 100%;
  }
}

.section4__flex_column6 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex-grow: 1;
  margin: 20px 20px 41px 0px;
}
@media (max-width: 1199px) {
  .section4__flex_column6 {
    margin: 20px 16px 41px;
  }
}
@media (max-width: 991px) {
  .section4__flex_column6 {
    margin: 20px 12px 41px;
  }
}
@media (max-width: 575px) {
  .section4__flex_column6 {
    margin: 20px 8px 41px;
  }
}

.section4__flex_column6 > .item {
  display: flex;
  flex-direction: column;
  position: relative;
}

.section4__image4 {
  width: 19px;
  height: auto;
  vertical-align: top;
  -o-object-fit: contain;
  object-fit: contain;
  -o-object-position: center top;
  object-position: center top;
  position: relative;
  min-width: 19px;
  margin: 0px 36px;
}
@media (max-width: 1199px) {
  .section4__image4 {
    margin: 0px 28px;
  }
}
@media (max-width: 991px) {
  .section4__image4 {
    margin: 0px 24px;
  }
}
@media (max-width: 767px) {
  .section4__image4 {
    margin: 0px 20px;
  }
}
@media (max-width: 479px) {
  .section4__image4 {
    margin: 0px 16px;
  }
}

.section4__group1 {
  display: flex;
  flex-direction: column;
  background-color: #56565c;
  position: relative;
  margin: 11px 0px 0px;
}

.section4__rect6 {
  background-color: #f3f3f4;
  height: 4px;
  position: relative;
  margin: 0px 29px 0px 0px;
}
@media (max-width: 1199px) {
  .section4__rect6 {
    margin: 0px 24px 0px 0px;
  }
}
@media (max-width: 991px) {
  .section4__rect6 {
    margin: 0px 20px 0px 0px;
  }
}
@media (max-width: 767px) {
  .section4__rect6 {
    margin: 0px 16px 0px 0px;
  }
}
@media (max-width: 479px) {
  .section4__rect6 {
    margin: 0px 12px 0px 0px;
  }
}

.section4__wrapper3 {
  display: flex;
  background-color: #313134;
  position: relative;
  margin: 15px 0px 0px;
}
@media (max-width: 1399px) {
  .section4__wrapper3 {
    flex-wrap: wrap;
    justify-content: flex-start;
    align-content: flex-start;
    -moz-column-gap: 0px;
    column-gap: 0px;
    row-gap: 16px;
  }
}

.section4__wrapper3 > .item {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 146px;
}
@media (max-width: 1399px) {
  .section4__wrapper3 > .item {
    flex: 0 0 calc(50% - 8px);
  }
}
@media (max-width: 1199px) {
  .section4__wrapper3 > .item {
    flex: 0 0 100%;
  }
}

.section4__wrapper3 > .spacer {
  flex: 0 1 20px;
}
@media (max-width: 1399px) {
  .section4__wrapper3 > .spacer {
    display: flex;
    flex: 0 0 16px;
  }
}
@media (max-width: 1199px) {
  .section4__wrapper3 > .spacer {
    display: none;
  }
}

.section4__wrapper3 > .item1 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 78px;
}
@media (max-width: 1399px) {
  .section4__wrapper3 > .item1 {
    flex: 0 0 calc(50% - 8px);
  }
}
@media (max-width: 1199px) {
  .section4__wrapper3 > .item1 {
    flex: 0 0 100%;
  }
}

.section4__wrapper3 > .spacer1 {
  flex: 0 1 20px;
}
@media (max-width: 1399px) {
  .section4__wrapper3 > .spacer1 {
    display: none;
  }
}

.section4__wrapper3 > .item2 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 775px;
}
@media (max-width: 1399px) {
  .section4__wrapper3 > .item2 {
    flex: 0 0 calc(50% - 8px);
  }
}
@media (max-width: 1199px) {
  .section4__wrapper3 > .item2 {
    flex: 0 0 100%;
  }
}

.section4__flex_row8 > .spacer1 {
  flex: 0 1 448px;
}

.section4__wrapper3 > .item3 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 111px;
}
@media (max-width: 1399px) {
  .section4__wrapper3 > .item3 {
    flex: 0 0 calc(50% - 8px);
  }
}
@media (max-width: 1199px) {
  .section4__wrapper3 > .item3 {
    flex: 0 0 100%;
  }
}

.section4__flex_column6 > .item1 {
  display: flex;
  flex-direction: column;
  position: relative;
}

.section4__wrapper3 > .item4 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 146px;
}
@media (max-width: 1399px) {
  .section4__wrapper3 > .item4 {
    flex: 0 0 calc(50% - 8px);
  }
}
@media (max-width: 1199px) {
  .section4__wrapper3 > .item4 {
    flex: 0 0 100%;
  }
}

.section4__wrapper3 > .spacer2 {
  flex: 0 1 20px;
}
@media (max-width: 1399px) {
  .section4__wrapper3 > .spacer2 {
    display: flex;
    flex: 0 0 16px;
  }
}
@media (max-width: 1199px) {
  .section4__wrapper3 > .spacer2 {
    display: none;
  }
}

.section4__wrapper3 > .item5 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 78px;
}
@media (max-width: 1399px) {
  .section4__wrapper3 > .item5 {
    flex: 0 0 calc(50% - 8px);
  }
}
@media (max-width: 1199px) {
  .section4__wrapper3 > .item5 {
    flex: 0 0 100%;
  }
}

.section4__wrapper3 > .spacer3 {
  flex: 0 1 20px;
}
@media (max-width: 1399px) {
  .section4__wrapper3 > .spacer3 {
    display: none;
  }
}

.section4__wrapper3 > .item6 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 775px;
}
@media (max-width: 1399px) {
  .section4__wrapper3 > .item6 {
    flex: 0 0 calc(50% - 8px);
  }
}
@media (max-width: 1199px) {
  .section4__wrapper3 > .item6 {
    flex: 0 0 100%;
  }
}

.section4__flex_row8 > .spacer2 {
  flex: 0 1 448px;
}

.section4__wrapper3 > .item7 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 111px;
}
@media (max-width: 1399px) {
  .section4__wrapper3 > .item7 {
    flex: 0 0 calc(50% - 8px);
  }
}
@media (max-width: 1199px) {
  .section4__wrapper3 > .item7 {
    flex: 0 0 100%;
  }
}

.section4__flex_column6 > .item2 {
  display: flex;
  flex-direction: column;
  position: relative;
}

.section4__wrapper3 > .item8 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 146px;
}
@media (max-width: 1399px) {
  .section4__wrapper3 > .item8 {
    flex: 0 0 calc(50% - 8px);
  }
}
@media (max-width: 1199px) {
  .section4__wrapper3 > .item8 {
    flex: 0 0 100%;
  }
}

.section4__wrapper3 > .spacer4 {
  flex: 0 1 20px;
}
@media (max-width: 1399px) {
  .section4__wrapper3 > .spacer4 {
    display: flex;
    flex: 0 0 16px;
  }
}
@media (max-width: 1199px) {
  .section4__wrapper3 > .spacer4 {
    display: none;
  }
}

.section4__wrapper3 > .item9 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 78px;
}
@media (max-width: 1399px) {
  .section4__wrapper3 > .item9 {
    flex: 0 0 calc(50% - 8px);
  }
}
@media (max-width: 1199px) {
  .section4__wrapper3 > .item9 {
    flex: 0 0 100%;
  }
}

.section4__wrapper3 > .spacer5 {
  flex: 0 1 20px;
}
@media (max-width: 1399px) {
  .section4__wrapper3 > .spacer5 {
    display: none;
  }
}

.section4__wrapper3 > .item10 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 775px;
}
@media (max-width: 1399px) {
  .section4__wrapper3 > .item10 {
    flex: 0 0 calc(50% - 8px);
  }
}
@media (max-width: 1199px) {
  .section4__wrapper3 > .item10 {
    flex: 0 0 100%;
  }
}

.section4__flex_row8 > .spacer3 {
  flex: 0 1 448px;
}

.section4__wrapper3 > .item11 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 111px;
}
@media (max-width: 1399px) {
  .section4__wrapper3 > .item11 {
    flex: 0 0 calc(50% - 8px);
  }
}
@media (max-width: 1199px) {
  .section4__wrapper3 > .item11 {
    flex: 0 0 100%;
  }
}

.section4__flex_column6 > .item3 {
  display: flex;
  flex-direction: column;
  position: relative;
}

.section4__flex_row7 > .spacer {
  flex: 0 1 15px;
}
@media (max-width: 1399px) {
  .section4__flex_row7 > .spacer {
    display: none;
  }
}

.section4__flex_row7 > .item1 {
  display: flex;
  flex-direction: column;
  position: relative;
  flex: 1 1 15px;
}
@media (max-width: 1399px) {
  .section4__flex_row7 > .item1 {
    flex: 0 0 100%;
  }
}

.section4__wrapper4 {
  display: flex;
  flex-direction: column;
  background-color: #353538;
  position: relative;
  flex-grow: 1;
}

.section4__rect8 {
  background-color: #d9d9d9;
  height: 292px;
  position: relative;
  margin: 23px 0px 128px;
}
</style>
