<template>
  <div class="total_wrapper">
    <h1 class="contacts-h1">Контакты</h1>

    <div class="container">
      <div class="row">
        <div class="col-3 col-xs-12">
          <p class="contacts-title">Как с нами связаться</p>
          <p class="contacts-text">
            <img
              src="@/assets/img/phone.svg"
              style="margin-right: 5px"
              alt=""
            />
            +7 999 999 99 99
          </p>
          <p class="contacts-text">
            <img src="@/assets/img/mail.svg" style="margin-right: 5px" alt="" />
            info@domen.ru
          </p>
        </div>
        <div class="col-9 col-xs-12">
          <iframe
            src="https://yandex.ru/map-widget/v1/?um=constructor%3A01229faa9df9bc37286d03fb075b8640eb41de7ceaaefa06540eb6ececd12d22&amp;source=constructor"
            width="100%"
            height="400"
            frameborder="0"
          ></iframe>
          <p class="contacts-text" style="margin-top: 20px">
            <img
              src="@/assets/img/where.svg"
              style="margin-right: 5px"
              alt=""
            />

            123456 Российская Федерация, г. Пермь, улица Пушкина, дом
            Колотушкина.
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "contacts-view",
};
</script>

<style scoped>
.contacts-h1 {
  font-weight: 900;
  font-size: 40px;
  margin-bottom: 30px;
  text-align: center;
  text-transform: lowercase;

  color: #f3f3f4;
  margin-top: 80px;
}
.row {
  display: flex;
}
.col-3 {
  width: 25%;
}
.col-9 {
  width: 75%;
}
.contacts-title {
  font-weight: 600;
  font-size: 20px;
  color: #ffffff;
  margin-bottom: 20px;
}
.contacts-text {
  font-weight: 400;
  font-size: 16px;
  color: #d9d9d9;
  margin-bottom: 10px;
}
</style>
