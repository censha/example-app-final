<?php

namespace App\Http\Controllers;

use App\Models\News;
use Illuminate\Http\Request;

class NewsController extends Controller
{
    public function show($id){

        $main = News::where('id', '!=', $id)->limit(3)->get();
        //dd($main);
        return inertia('NewsPageView', [
            'news' => News::find($id),
            'main' => $main
        ]);
    }
}
