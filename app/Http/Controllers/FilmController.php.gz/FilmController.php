<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;

use App\Models\Film;
use App\Models\Tags;
use App\Models\VideoTheme;
use App\Models\VideoCollection;
use App\Models\VideoType;
use App\Models\Storage;
use Illuminate\Http\Request;
use Inertia\Inertia;
use App\Models\Actor;
use App\Models\Poster;
use App\Models\Scenarist;
use App\Models\Regeser;
use App\Models\Audio;

    class FilmController extends Controller
{

    public function index(){

        // $films = Film::join('fileapp_filebunner', 'fileapp_filebunner.id', '=', 'videosapp_video.banner_file_id')
        // ->join('fileapp_filebunner_storages', 'fileapp_filebunner_storages.filebunner_id', '=', 'fileapp_filebunner.id')
        // ->join( 'fileapp_storages', 'fileapp_filebunner_storages.storages_id', '=', 'fileapp_storages.id')
        // ->select(
        //     //'fileapp_filevideo.*',
        //     'videosapp_video.*',
        //     'fileapp_storages.prefix',
        //     'fileapp_filebunner.file_path',
        //     'fileapp_filebunner.file_name',
        // )->get();
        //dd($Film::all());
        $tagfilms = Tags::join('videosapp_video_tags', 'videosapp_video_tags.tags_id', '=', 'tagsapp_tags.id')->get();
        //dd(Film::all()->paginate(4));

        return Inertia::render('KinoArchiveView', [
           'films' => Film::paginate(15),
           'tags' => Tags::all(),
           'themes' => VideoTheme::all(),
           'types' => VideoType::all(),
           'collections'=> VideoCollection::all(),
           'lastFilms' => Film::orderByDesc('id')->limit(6)->get(),
           'tagfilms' => $tagfilms,
        ]);
    }
    
    public function filter(Request $request)
    {
        $films = Film::where('videosapp_video.id', '>', 0);
        $tagfilms = Tags::join('videosapp_video_tags', 'videosapp_video_tags.tags_id', '=', 'tagsapp_tags.id')->get();
        //return dd($films);
        if($request->input("digitise")){
            switch($request->input("digitise")){
                case '0': break;
                case '1':
                    $films = $films->where('is_digit', true);
                    break;
                case '2':
                    $films = $films->where('is_digit', false);
                    break;
            }
        
        };
        if($request->input("quality")){
            $quality = explode(",", $request->input("quality"));
            $films = $films->whereIn('quality', $quality);
        }
        
        if($request->input("issue_year_from")){
            $films = $films->where('date_release', '>' ,$request->input("issue_year_from"));
        }
        if($request->input("issue_year_to")){
            $films = $films->where('date_release', '<' ,$request->input("issue_year_to"));
        }
        if($request->input("chronicle_year_from")){
            $films = $films->where('year_movie', '>' ,$request->input("chronicle_year_from"));
        }
        if($request->input("chronicle_year_to")){
            $films = $films->where('year_movie', '<' ,$request->input("chronicle_year_to"));
        }



        if($request->input("type_kino")){
            $films = $films->where('types_id', $request->input("type_kino"));
        }
        if($request->input("video_collection")){
            $films = $films->where('collections_id', $request->input("video_collection"));
        }
        if($request->input("tems")){
            $films = $films->where('tems_id', $request->input("tems"));
        }
        //return dd($films);
        if($request->input("sort_method")){
            switch($request->input("sort_method")){
                case "date":
                    $films = $films->orderBy('created_at');
                    break;
                case "yearAsc":
                    $films = $films->orderBy('year_movie');
                    break;
                case "yearDesc":
                    $films = $films->orderBy('year_movie', 'desc');
                    break;
            }
        }
        //dd($films);
        //------------Проверка
        $films = $films->paginate(15);
        if($request->input("tags")){
            $tags = explode(",", $request->input("tags"));
            //dd($tags);
            if(count($tags)>0){
                //$films = $films
                //    ->join('videosapp_video_tags', 'videosapp_video_tags.video_id', '=', 'videosapp_video.id')
                //    ->whereIn('videosapp_video_tags.tags_id', $tags)
                //    ->selectRaw("count(videosapp_video_tags.video_id) as counter")
                //    ->groupBy('videosapp_video.id');
                //dd($films->get());
                $films = $films->filter(function($film)use($tags){
                    return DB::table("videosapp_video_tags")
                        ->where('video_id', $film->id)
                        ->whereIn('tags_id', $tags)
                        ->count() > 0;
                });
            }
        }
        return Inertia::render('KinoArchiveView', [
            'films' => $films,
            'tags' => Tags::all(),
            'themes' => VideoTheme::all(),
            'types' => VideoType::all(),
            'collections' => VideoCollection::all(),
            'lastFilms' => Film::orderByDesc('id')->limit(6)->get(),
            'tagfilms' => $tagfilms,
            'filter'=> [
                'digitise' => $request->input("digitise"),
                'is_digit' => $request->input("is_digit"),
                'quality' => $request->input("quality"),
                'tags' => $request->input("tags"),
                'issue_year_from' => $request->input("issue_year_from"),
                'issue_year_to' => $request->input("issue_year_to"),
                'chronicle_year_from' => $request->input("chronicle_year_from"),
                'chronicle_year_to' => $request->input("chronicle_year_to"),
                'type_kino' => $request->input("type_kino"),
                'video_collection' => $request->input("video_collection"),
                'tems' => $request->input("tems"),
                'sort_method' => $request->input("sort_method"),
                'from' => $request->input("from"),
                'to' => $request->input("to"),
           ]
        ]);
    }

    public function film($id){
        $film = Film::find($id);
        // ->join('fileapp_filevideo', 'fileapp_filevideo.id', '=', 'videosapp_video.video_file_id')
        // ->join('fileapp_filevideo_storages', 'fileapp_filevideo_storages.filevideo_id', '=', 'fileapp_filevideo.id')
        // ->join('fileapp_storages', 'fileapp_filevideo_storages.storages_id', '=', 'fileapp_storages.id')
        // ->select(
        //     'fileapp_filevideo.*',
        //     'videosapp_video.*',
        //     'fileapp_storages.prefix',
        //     //'fileapp_filebunner.*'
        // )->first();
        // $banner = Storage::join('fileapp_filebunner_storages', 'fileapp_filebunner_storages.storages_id', '=', 'fileapp_storages.id')
        // ->join('fileapp_filebunner', 'fileapp_filebunner.id', '=', 'fileapp_filebunner_storages.filebunner_id')
        // ->join('videosapp_video', 'videosapp_video.banner_file_id', '=', 'fileapp_filebunner.id' )
        // ->select(
        //     'fileapp_storages.prefix',
        //     'fileapp_filebunner.file_path',
        //     'fileapp_filebunner.file_name',
        // )
        // ->first();
        //dd($tags);
        $tags = Tags::join('videosapp_video_tags', 'videosapp_video_tags.tags_id', '=', 'tagsapp_tags.id')
        ->where('videosapp_video_tags.video_id', $id)
        ->get();
        $actor = Actor::join('videosapp_video_acter', 'videosapp_video_acter.acter_id', '=', 'authorsapp_authors.id')
        ->where('videosapp_video_acter.video_id', $id)
        ->get();
        $operator = Actor::join('videosapp_video_operator', 'videosapp_video_operator.operator_id', '=', 'authorsapp_authors.id')
        ->where('videosapp_video_operator.video_id', $id)
        ->first();
        $produsser = Actor::join('videosapp_video_produsser', 'videosapp_video_produsser.produsser_id', '=', 'authorsapp_authors.id')
        ->where('videosapp_video_produsser.video_id', $id)
        ->first();
        $regeser = Actor::join('videosapp_video_regesers', 'videosapp_video_regesers.regesers_id', '=', 'authorsapp_authors.id')
        ->where('videosapp_video_regesers.video_id', $id)
        ->first();
        $scenarist = Actor::join('videosapp_video_scenarist', 'videosapp_video_scenarist.scenarist_id', '=', 'authorsapp_authors.id')
        ->where('videosapp_video_scenarist.video_id', $id)
        ->first();
        $poster = Poster::join('videosapp_video_posters', 'videosapp_video_posters.poster_id', '=', 'postersapp_poster.id')
        ->where('videosapp_video_posters.video_id', $id)
        ->get();
        $audio = Audio::join('videosapp_video_audio_vs_film', 'videosapp_video_audio_vs_film.audio_id', '=', 'audioapp_audio.id')
        ->select(
            'audioapp_audio.*',
            'videosapp_video_audio_vs_film.video_id'
        )
        ->where('videosapp_video_audio_vs_film.video_id', $id)
        ->get();                ;
        //dd($audio);
        return Inertia::render('FilmCardView', [
            'film' => $film,
            'tads' => $tags,
            'actors' => $actor,
            'operators' => $operator,
            'produssers' => $produsser,
            'regesers' => $regeser,
            'scenarists' => $scenarist,
            'posters' => $poster,
            'audios' => $audio,
        //'banner' =>  $banner
        ]
        );
    }

    public function show($id){
        $film = Film::find($id)->
        join('fileapp_filevideo', 'fileapp_filevideo.id', '=', 'videosapp_video.video_file_id')
        ->join('fileapp_filevideo_storages', 'fileapp_filevideo_storages.filevideo_id', '=', 'fileapp_filevideo.id')
        ->join('fileapp_storages', 'fileapp_filevideo_storages.storages_id', '=', 'fileapp_storages.id')
        //->join()
        ->select(
            'fileapp_filevideo.*',
            'videosapp_video.*',
            //'fileapp_filevideo_storages.*',
            'fileapp_storages.prefix'
        )->first();

        return Inertia::render('VideoExample'
        , ['film' => $film ]
        );
    }

    public function create(Request $request, $id){
        //dd(auth()->user()->id);
        if(auth()->user()->id) {
            // $film = Regeser::create([
            //     'start_segment' => $request->min, 
            //     'end_segment' => $request->max,
            //     'segment_path' => 'path'
            // ]);
            //$film->id;
            
            $create = Scenarist::create([ 
                'answer' => false,           
                'film_id' => $id,
                'user_id'=> auth()->user()->id,
                //'segment_film_id' => $film->filevideo_ptr_id,
                'end_segment'=> $request->min,
                'start_segment' => $request->max,
                ]
            );   
            //dd($create);         
        }        
        return redirect()->back();
    }
}
