<?php

namespace App\Http\Controllers;

use App\Models\Photo;
use App\Models\PhotoCollection;
use Illuminate\Http\Request;
use Inertia\Inertia;

class PhotoController extends Controller
{
    public function index(){
        $photocollection = PhotoCollection::orderBy('id', 'desc')->limit(7)->get();
        $photo = PhotoCollection::paginate(24);
        //dd($photocollection);
        return Inertia::render('PhotoAlbumView',[
            'photocollections' => $photocollection,
            'photos' => $photo,
        ]);
    }

    public function show($id){
        $photos = Photo::where('photo_collections_id', $id)->get();
        //dd($photos);
        $photocollection = PhotoCollection::find($id);
        return Inertia::render('PhotoAlbum', ['photos' => $photos, 'photocollection' => $photocollection]);
    }
   

    public function  showphoto($id){
        $photo = Photo::where('id', $id)
        ->join('authorsapp_authors', 'authorsapp_authors.id', '=', 'photoapp_photo.author_hoto_id')
        ->select(
            'photoapp_photo.*',
            'authorsapp_authors.name as author_hoto',
        )
        ->get();

        //dd($photo);
        $photocollection = PhotoCollection::find($id);
        return Inertia::render('PhotoView', ['photos' => $photo, 'photocollection' => $photocollection]);
    }



}
