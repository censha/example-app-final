<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PersonalController extends Controller
{
    //
    public function updatePhoto(Request $request){
        dd($request->photo);
        
    }
}
