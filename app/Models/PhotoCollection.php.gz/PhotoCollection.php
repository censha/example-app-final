<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PhotoCollection extends Model
{
    use HasFactory;

    protected $table = 'photoapp_photocollectiions';

    protected $fillable = [
        'name',
        'banner',
        'photo_cat'
    ];


}
